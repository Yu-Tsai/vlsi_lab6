@nLint rc file Version 1.0
[Compilation&Elaboration.11001]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11003]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11005]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11007]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11009]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11011]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11013]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11015]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11017]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11019]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11021]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11023]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11025]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11027]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11029]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11031]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11033]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11035]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11037]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11039]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11041]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11043]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11045]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11047]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11049]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11051]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11053]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11055]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11057]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11059]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11061]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11063]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11065]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11067]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11069]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11071]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11073]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11075]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11077]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11079]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11081]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11083]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11085]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11087]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11089]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11091]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11093]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11095]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11097]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11099]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11101]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11103]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11105]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11107]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11109]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11111]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11113]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.11115]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.15003]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.15005]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.15007]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.15009]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.15011]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.15013]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.15015]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.15017]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.15019]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.15021]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.15023]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.15025]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.15027]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.15029]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.15031]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.15033]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.15035]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.15037]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.15039]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.15041]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.15043]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.15045]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.15047]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.15049]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16001]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16003]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16005]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16007]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16009]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16011]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16013]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16015]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16017]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16019]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16021]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16023]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16025]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16027]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16029]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16031]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16033]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16035]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16037]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16039]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16041]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16043]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16045]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16047]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16049]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16051]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16053]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16055]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16057]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16059]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16061]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16063]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16065]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16067]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16069]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16071]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16073]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16075]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16077]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16079]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16081]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16083]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16085]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16087]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16089]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16091]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16093]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16095]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16097]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16099]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16101]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16103]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16105]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16107]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16109]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16111]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16113]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16115]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16117]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16119]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16121]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16123]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16125]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16127]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16129]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16131]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16133]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16135]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16137]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16139]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16141]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16143]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16145]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16147]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16149]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16151]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16153]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16155]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16157]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16159]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16161]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16163]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16165]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16167]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16169]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16171]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16173]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16175]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16177]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16179]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16181]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16183]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16185]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16187]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16189]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16191]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16193]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16195]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16197]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16199]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16201]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16203]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16205]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16207]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16209]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16211]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16213]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16215]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16217]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16219]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16221]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16223]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16225]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16227]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16229]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16231]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16233]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16235]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16237]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16239]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16241]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16243]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16245]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16247]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16249]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16251]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16253]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16255]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16257]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16259]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16261]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16263]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16265]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16267]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16269]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16271]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16273]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16275]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16277]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16279]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16281]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16283]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16285]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16287]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16289]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16291]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16293]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16295]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16297]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16299]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16301]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16303]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16305]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16307]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16309]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16311]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16313]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16315]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16317]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16319]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16321]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16323]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16325]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16327]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16329]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16331]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16333]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16335]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16337]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16339]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16341]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16343]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16345]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16347]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16349]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16351]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16353]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16355]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16357]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16359]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16361]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16363]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16365]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16367]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16369]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16371]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16373]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16375]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16377]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16379]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16381]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16383]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16385]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16387]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16389]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16391]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16393]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16395]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16397]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16399]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16401]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16403]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16405]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16407]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16409]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16411]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16413]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16415]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16417]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16419]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16421]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16423]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16425]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16427]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16429]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16431]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16433]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16435]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16437]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16439]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16441]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16443]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16445]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16447]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16449]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16451]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16453]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16455]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16457]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16459]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16461]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16463]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16465]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16467]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16469]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16471]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16473]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16475]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16477]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16479]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16481]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16483]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16485]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16487]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16489]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16491]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16493]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16495]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16497]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16499]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16501]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16503]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16505]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16507]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16509]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16511]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16513]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16515]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16517]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16519]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16521]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16523]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16525]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16527]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16529]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16531]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16533]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16535]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16537]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16539]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16541]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16543]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16545]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16547]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16549]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16551]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16553]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16555]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16557]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16559]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16561]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16563]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16565]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16567]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16569]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16571]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16573]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16575]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16577]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16579]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16581]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16583]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16585]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16587]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16589]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16591]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16593]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16595]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16597]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16599]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16601]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16603]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16605]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16607]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16609]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16611]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16613]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16615]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16617]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16619]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16621]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16623]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16625]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16627]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16629]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16631]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16635]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16637]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16641]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16643]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16645]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16647]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16649]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16651]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16653]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16655]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16657]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16659]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16661]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16663]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16665]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16667]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16669]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16671]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16673]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16675]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16677]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16679]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16681]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16683]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16685]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16687]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16689]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16691]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16693]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16695]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16697]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16699]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16701]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16703]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16705]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16707]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16709]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16711]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16713]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16715]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16717]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16719]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16721]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16723]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16725]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16727]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16729]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16731]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16733]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16735]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16737]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16739]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16741]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16743]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16745]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16747]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16749]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16751]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16753]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16755]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16757]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16759]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16761]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16763]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16765]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16767]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16769]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16771]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16773]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16775]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16777]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16779]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16781]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16783]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16785]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16787]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16789]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16791]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16793]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16795]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16797]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16799]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16801]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16803]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16805]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16807]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16809]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16811]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16813]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16815]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16817]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16819]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16821]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16823]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16825]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16827]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16829]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16831]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16833]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16835]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16837]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16839]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16841]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16843]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16845]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16847]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16849]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16851]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16853]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16855]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16857]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16859]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16861]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16863]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16865]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16867]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16869]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16871]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16873]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16875]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16877]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16879]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16881]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16883]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16885]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16887]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16889]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16891]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16893]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16895]
vlog_severity = Level1
vhdl_severity = Level2
[Compilation&Elaboration.16897]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16899]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16901]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16903]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16905]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16907]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16909]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16911]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16913]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16915]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16917]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.16919]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16921]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16923]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16925]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16927]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16929]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16931]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16933]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.16935]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.16937]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.16939]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.16941]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16943]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16945]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16947]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.16949]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.16951]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.16953]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.16955]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.16957]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16959]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.16961]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16962]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16963]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16964]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16965]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16967]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16969]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16971]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.16973]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.16975]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16977]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16979]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16981]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16983]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16985]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16987]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.16989]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.16991]
vlog_severity = Level3
vhdl_severity = Level2
[Compilation&Elaboration.16993]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.16995]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.16997]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.16999]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.17000]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.17010]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.17020]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.17030]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.17040]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.17050]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.17057]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.17060]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.17064]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.17072]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.17079]
vlog_severity = Level2
vhdl_severity = Level1
[Compilation&Elaboration.17080]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.17090]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.17091]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.17100]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.17150]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.17160]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.17170]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.17180]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.17190]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.17200]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.17210]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.17220]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.17595]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.17596]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18001]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18002]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18003]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18004]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18005]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18006]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18013]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18070]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.18101]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18102]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18104]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18105]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18120]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18130]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18140]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18141]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18142]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18143]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18150]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18151]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18160]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18170]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18171]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18172]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18180]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18190]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18191]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18200]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18210]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18211]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18220]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18230]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18231]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18232]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18233]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18240]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18241]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18242]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18245]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18250]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18260]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18270]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18280]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18290]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18300]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18310]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18320]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18330]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18331]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18340]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18350]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18360]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18370]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18380]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18390]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18400]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18410]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18420]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18430]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18440]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18441]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18450]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18460]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18470]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18471]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18480]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18490]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18500]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18510]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18511]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18520]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18530]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18540]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18541]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18542]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18550]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18560]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18570]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18571]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18575]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18576]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18577]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18580]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18581]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18582]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18585]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18590]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18600]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18605]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18610]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18615]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18620]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18625]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18630]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18635]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18636]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18637]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18640]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18645]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18648]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18649]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18650]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18655]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18656]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18660]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18665]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18670]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18680]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18690]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18700]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18701]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18705]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18706]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18710]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18715]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18720]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18725]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18728]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18729]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18730]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18735]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18736]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18740]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18742]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18743]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18745]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18746]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18750]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18755]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18760]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18765]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18770]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18772]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18773]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18775]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18778]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18780]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18782]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18785]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18788]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18790]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18792]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18795]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18796]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18797]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18799]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18800]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18802]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18803]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18805]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18807]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18808]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18810]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18811]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18812]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18813]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18815]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18816]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18817]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18820]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18822]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18825]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18826]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18827]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18828]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18830]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.18832]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18835]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18836]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18837]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18838]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18839]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18840]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18842]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18843]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18844]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18845]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18846]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18847]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18848]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18849]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18850]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18851]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18852]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18853]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18854]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18855]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18856]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.18857]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18860]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18861]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18862]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18863]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18864]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18865]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18866]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18868]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18870]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18871]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18875]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18876]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18877]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18878]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18879]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18880]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18881]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18882]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18885]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.18903]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.19006]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.19007]
vlog_severity = Level2
vhdl_severity = Level3
[Compilation&Elaboration.19009]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.19073]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.19074]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.19075]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.19076]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.20201]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.20203]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.20205]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.20207]
vlog_severity = Level2
vhdl_severity = Level2
[Compilation&Elaboration.Compilation&Elaboration]
16057 = Disable NONE TRUE NONE
[Default]
Default = "nLint"
[Groups]
1 = "nLint"
2 = "RMM"
3 = "IPQ Design Guidelines"
[IPQ Design Guidelines.21001]
vlog_severity = Level2
vlog_indexname = NC.9-1
vhdl_indexname = NC.9-1
vlog_val = CASE_LOWER
vlog_description = "Signals names are lowercase letters"
vhdl_description = "Signals names are lowercase letters"
vhdl_severity = Level2
vhdl_val = CASE_LOWER
[IPQ Design Guidelines.21005]
vlog_severity = Level2
vlog_indexname = NC.9-5
vhdl_indexname = NC.9-5
vlog_val = CASE_LOWER
vlog_description = "Port names are lowercase letters"
vhdl_description = "Port names are lowercase letters"
vhdl_severity = Level2
vhdl_val = CASE_LOWER
[IPQ Design Guidelines.21007]
vlog_severity = Level2
vlog_indexname = NC.19-1
vhdl_indexname = NC.19-1
vlog_val = 32
vlog_description = "The length of signal names does not exceed 32 characters"
vhdl_description = "The length of signal names does not exceed 32 characters"
vhdl_severity = Level2
vhdl_val = 32
[IPQ Design Guidelines.21009]
vlog_severity = Level2
vlog_indexname = NC.19-2
vhdl_indexname = NC.19-2
vlog_val = 32
vlog_description = "The length of signal names does not exceed 32 characters"
vhdl_description = "The length of signal names does not exceed 32 characters"
vhdl_severity = Level2
vhdl_val = 32
[IPQ Design Guidelines.21013]
vlog_severity = Level2
vlog_indexname = NC.11
vhdl_indexname = NC.11
vlog_val = SUB_STRING,clk
vlog_description = "Consistent clock signal name"
vhdl_description = "Consistent clock signal name"
vhdl_severity = Level2
vhdl_val = SUB_STRING,clk
[IPQ Design Guidelines.21014]
vlog_severity = Level1
vlog_indexname = NC.15
vhdl_indexname = NC.15
vlog_val = SUFFIX,_lat
vlog_description = "For latch variables, end in _lat"
vhdl_description = "For latch variables, end in _lat"
vhdl_severity = Level1
vhdl_val = SUFFIX,_lat
[IPQ Design Guidelines.21015]
vlog_severity = Level2
vlog_indexname = NC.12
vhdl_indexname = NC.12
vlog_val = SUB_STRING,rst
vlog_description = "Consistent reset signal name"
vhdl_description = "Consistent reset signal name"
vhdl_severity = Level2
vhdl_val = SUB_STRING,rst
[IPQ Design Guidelines.21019]
vlog_severity = Level1
vlog_indexname = NC.14-1
vhdl_indexname = NC.14-1
vlog_val = SUFFIX,_cs
vlog_description = "For FSM variables, naming in <fsm_cs>, <fsm_ns>"
vhdl_description = "For FSM variables, naming in <fsm_cs>, <fsm_ns>"
vhdl_severity = Level1
vhdl_val = SUFFIX,_cs
[IPQ Design Guidelines.21020]
vlog_severity = Level2
vlog_indexname = NC.13
vhdl_indexname = NC.13
vlog_val = SUFFIX,_n
vlog_description = "Consistent active-low signal name"
vhdl_description = "Consistent active-low signal name"
vhdl_severity = Level2
vhdl_val = SUFFIX,_n
[IPQ Design Guidelines.21023]
vlog_severity = Level2
vlog_indexname = NC.23
vhdl_indexname = NC.23
vlog_val = ZERO_BOUND,DOWN_TO
vlog_description = "Consistent ordering of bits for describing multibit buses"
vhdl_description = "Consistent ordering of bits for describing multibit buses"
vhdl_severity = Level2
vhdl_val = ZERO_BOUND,DOWN_TO
[IPQ Design Guidelines.21029]
vlog_severity = Level1
vlog_indexname = NC.17
vhdl_indexname = NC.17
vlog_val = SUFFIX,_a
vlog_description = "For asynchronous signals, end in _a"
vhdl_description = "For asynchronous signals, end in _a"
vhdl_severity = Level1
vhdl_val = SUFFIX,_a
[IPQ Design Guidelines.21031]
vlog_severity = Level1
vlog_indexname = NC.16
vhdl_indexname = NC.16
vlog_val = SUFFIX,_z
vlog_description = "For tri-state signals, end in _z"
vhdl_description = "For tri-state signals, end in _z"
vhdl_severity = Level1
vhdl_val = SUFFIX,_z
[IPQ Design Guidelines.21041]
vlog_severity = Level2
vlog_indexname = NC.8-1
vhdl_indexname = NC.8-1
vlog_val = CASE_UPPER
vlog_description = "Parameters are uppercase letters"
vhdl_severity = Level2
vhdl_val = CASE_UPPER
[IPQ Design Guidelines.21043]
vlog_severity = Level2
vlog_indexname = NC.1
vhdl_indexname = NC.1
vlog_val = CHECK_ALL_MODULE
vlog_description = "A file must contain at most one module unit"
vhdl_description = "A file must contain at most one module unit"
vhdl_severity = Level2
vhdl_val = CHECK_ALL_MODULE
[IPQ Design Guidelines.21044]
vlog_severity = Level1
vlog_indexname = NC.2
vhdl_indexname = NC.2
vlog_description = "File name should be identical to design unit name"
vhdl_description = "File name should be identical to design unit name"
vhdl_severity = Level1
[IPQ Design Guidelines.21057]
vlog_severity = Level2
vlog_indexname = NC.7-2
vhdl_indexname = NC.7-2
vlog_val = PREFIX
vlog_description = "Use consistent clock signal names throughout the hierarchy"
vhdl_description = "Use consistent clock signal names throughout the hierarchy"
vhdl_severity = Level2
vhdl_val = PREFIX
[IPQ Design Guidelines.22002]
vlog_severity = Level2
vlog_indexname = DFT.1-2
vhdl_indexname = DFT.1-2
vlog_description = "Avoid tri-state device"
vhdl_description = "Avoid tri-state device"
vhdl_severity = Level2
[IPQ Design Guidelines.22003]
vlog_severity = Level3
vlog_indexname = CS.15-1
vhdl_indexname = CS.15-1
vlog_val = LHS_EQ_RHS,VAR_EQ_CON
vlog_description = "Operand size must match in assignment"
vhdl_description = "Operand size must match in assignment"
vhdl_severity = Level3
vhdl_val = LHS_EQ_RHS,VAR_EQ_CON
[IPQ Design Guidelines.22004]
vlog_severity = Level3
vlog_indexname = CS.15-2
vhdl_indexname = CS.15-2
vlog_val = VAR_EQ_CON
vlog_description = "Operand size must match in assignment"
vhdl_description = "Operand size must match in assignment"
vhdl_severity = Level3
vhdl_val = VAR_EQ_CON
[IPQ Design Guidelines.22007]
vlog_severity = Level1
vlog_indexname = DFT.10-2
vhdl_indexname = DFT.10-2
vlog_val = INPUT
vlog_description = "Avoid constant inputs on instance"
vhdl_description = "Avoid constant inputs on instance"
vhdl_severity = Level1
vhdl_val = INPUT
[IPQ Design Guidelines.22008]
vlog_severity = Level3
vlog_indexname = CS.11
vhdl_indexname = 22008
vlog_description = "Avoid expression in port connections"
vhdl_severity = Level2
[IPQ Design Guidelines.22011]
vlog_severity = Level2
vlog_indexname = DFT.9/STA.1
vhdl_indexname = DFT.9/STA.1
vlog_val = SYNC
vlog_description = "Avoid Combinational feedback loop"
vhdl_description = "Avoid Combinational feedback loop"
vhdl_severity = Level2
vhdl_val = SYNC
[IPQ Design Guidelines.22020]
vlog_severity = Level2
vlog_indexname = DFT.1-1
vhdl_indexname = DFT.1-1
vlog_description = "Avoid tri-state device"
vhdl_description = "Avoid tri-state device"
vhdl_severity = Level2
[IPQ Design Guidelines.22021]
vlog_severity = Level2
vlog_indexname = CS.13
vhdl_indexname = CS.13
vlog_description = "Use parentheses in complex equations"
vhdl_description = "Use parentheses in complex equations"
vhdl_severity = Level2
[IPQ Design Guidelines.22023]
vlog_severity = Level3
vlog_indexname = CS.3
vhdl_indexname = CS.3
vlog_description = "Use a separate line for each HDL statement"
vhdl_description = "Use a separate line for each HDL statement"
vhdl_severity = Level3
[IPQ Design Guidelines.22025]
vlog_severity = Level1
vlog_indexname = CS.7
vhdl_indexname = CS.7
vlog_val = 72
vlog_description = "Keep line length within 72 characters"
vhdl_description = "Keep line length within 72 characters"
vhdl_severity = Level1
vhdl_val = 72
[IPQ Design Guidelines.22027]
vlog_severity = Level2
vlog_indexname = CS.1
vhdl_indexname = CS.1
vlog_val = 2,"FIRST_INDENT, BEGIN_INDENT"
vlog_description = "Code should be aligned in a tabular format"
vhdl_description = "Code should be aligned in a tabular format"
vhdl_severity = Level2
vhdl_val = 2,"FIRST_INDENT, BEGIN_INDENT"
[IPQ Design Guidelines.22029]
vlog_severity = Level2
vlog_indexname = CS.2
vhdl_indexname = CS.2
vlog_val = CHECK_WHOLE
vlog_description = "Use space instead of tab stops for code indentation"
vhdl_description = "Use space instead of tab stops for code indentation"
vhdl_severity = Level2
vhdl_val = CHECK_WHOLE
[IPQ Design Guidelines.22031]
vlog_severity = Level3
vlog_indexname = CS.4
vhdl_indexname = CS.4
vlog_description = "Use a separate line for each port declaration"
vhdl_description = "Use a separate line for each port declaration"
vhdl_severity = Level3
[IPQ Design Guidelines.22032]
vlog_severity = Level3
vlog_indexname = COM.1
vhdl_indexname = COM.1
vlog_description = "Use comments for port declarations"
vhdl_description = "Use comments for port declarations"
vhdl_severity = Level3
[IPQ Design Guidelines.22038]
vlog_severity = Level1
vlog_indexname = COM.2
vhdl_indexname = COM.2
vlog_val = CHECK_COMMENT
vlog_description = "Comment signal declarations"
vhdl_description = "Comment signal declarations"
vhdl_severity = Level1
vhdl_val = CHECK_COMMENT
[IPQ Design Guidelines.22043]
vlog_severity = Level3
vlog_indexname = CS.10
vhdl_indexname = CS.10
vlog_val = MODULE
vlog_description = "Use explicit port mapping instead of positional association in module instantiation"
vhdl_description = "Use explicit port mapping instead of positional association in module instantiation"
vhdl_severity = Level3
vhdl_val = MODULE
[IPQ Design Guidelines.22053]
vlog_severity = Level2
vlog_indexname = D.4-1/DFT.5-1/STA.3-1
vhdl_indexname = D.4-1/DFT.5-1/STA.3-1
vlog_description = "Simplify the register clock origin--avoid gated clock"
vhdl_description = "Simplify the register clock origin--avoid gated clock"
vhdl_severity = Level2
[IPQ Design Guidelines.22054]
vlog_severity = Level2
vlog_indexname = D.4-2/DFT.5-2/STA.3-2
vhdl_indexname = D.4-2/DFT.5-2/STA.3-2
vlog_description = "Simplify the register clock origin--avoid inverted clock"
vhdl_description = "Simplify the register clock origin--avoid inverted clock"
vhdl_severity = Level2
[IPQ Design Guidelines.22055]
vlog_severity = Level2
vlog_indexname = D.4-3/DFT.5-3/STA.3-3
vhdl_indexname = D.4-3/DFT.5-3/STA.3-3
vlog_description = "Simplify the register clock origin--avoid buffered clock"
vhdl_description = "Simplify the register clock origin--avoid buffered clock"
vhdl_severity = Level2
[IPQ Design Guidelines.22056]
vlog_severity = Level2
vlog_indexname = DFT.7-1
vhdl_indexname = DFT.7-1
vlog_val = BOTH
vlog_description = "Internal clear"
vhdl_description = "Internal clear"
vhdl_severity = Level2
vhdl_val = BOTH
[IPQ Design Guidelines.22057]
vlog_severity = Level2
vlog_indexname = DFT.7-2
vhdl_indexname = DFT.7-2
vlog_val = BOTH
vlog_description = "Internal preset"
vhdl_description = "Internal preset"
vhdl_severity = Level2
vhdl_val = BOTH
[IPQ Design Guidelines.22063]
vlog_severity = Level1
vlog_indexname = CS.17
vhdl_indexname = CS.17
vlog_description = "Finite State Machine (FSM) coding style"
vhdl_description = "Finite State Machine (FSM) coding style"
vhdl_severity = Level1
[IPQ Design Guidelines.22082]
vlog_severity = Level3
vlog_indexname = SYN.6~7-1
vhdl_indexname = SYN.6~7-1
vlog_val = "INPUT, OUTPUT"
vlog_description = "All unused module inputs must be driven, outputs should be connected"
vhdl_description = "All unused module inputs must be driven, outputs should be connected"
vhdl_severity = Level3
vhdl_val = "INPUT, OUTPUT"
[IPQ Design Guidelines.22091]
vlog_severity = Level1
vlog_indexname = CS.16
vhdl_indexname = 22091
vlog_description = "Expression in condition should be 1- bit value"
vhdl_severity = Level2
[IPQ Design Guidelines.22112]
vlog_severity = Level3
vlog_indexname = SYN.1.6-3
vhdl_indexname = 22112
vlog_description = "Loop must be in a static range"
vhdl_severity = Level2
[IPQ Design Guidelines.22113]
vlog_severity = Level3
vlog_indexname = SYN.1.6-2
vhdl_indexname = SYN.1.6-2
vlog_description = "Loop must be in a static range"
vhdl_description = "Loop must be in a static range"
vhdl_severity = Level3
[IPQ Design Guidelines.22127]
vlog_severity = Level2
vlog_indexname = DFT.8-1/STA.5-1
vhdl_indexname = DFT.8-1/STA.5-1
vlog_description = "Avoid clocks as data (of registers)"
vhdl_description = "Avoid clocks as data (of registers)"
vhdl_severity = Level2
[IPQ Design Guidelines.22130]
vlog_severity = Level2
vlog_indexname = DFT.8-2/STA.5-2
vhdl_indexname = DFT.8-2/STA.5-2
vlog_description = "Avoid clocks as primary output"
vhdl_description = "Avoid clocks as primary output"
vhdl_severity = Level2
[IPQ Design Guidelines.22131]
vlog_severity = Level2
vlog_indexname = DFT.6/STA.3-4
vhdl_indexname = DFT.6/STA.3-4
vlog_description = "Simplify the register clock origin--Simplify the register clock origin--avoid sequential clock"
vhdl_description = "Simplify the register clock origin--Simplify the register clock origin--avoid sequential clock"
vhdl_severity = Level2
[IPQ Design Guidelines.22132]
vlog_severity = Level1
vlog_indexname = D.1.2
vhdl_indexname = D.1.2
vlog_description = "Registers in an IP's interface should be clocked in a single edge of the same clock"
vhdl_description = "Registers in an IP's interface should be clocked in a single edge of the same clock"
vhdl_severity = Level1
[IPQ Design Guidelines.22161]
vlog_severity = Level3
vlog_indexname = CS.14
vhdl_indexname = 22161
vlog_val = CHECK_ALL
vlog_description = "Wire must be explicitly declared"
vhdl_severity = Level2
[IPQ Design Guidelines.22165]
vlog_severity = Level1
vlog_indexname = DFT.10-1
vhdl_indexname = DFT.10-1
vlog_val = CHECK_ALL
vlog_description = "Avoid constant inputs in core"
vhdl_description = "Avoid constant inputs in core"
vhdl_severity = Level1
vhdl_val = CHECK_ALL
[IPQ Design Guidelines.22167]
vlog_severity = Level2
vlog_indexname = DFT.2
vhdl_indexname = DFT.2
vlog_description = "Avoid bi-directional nets"
vhdl_description = "Avoid bi-directional nets"
vhdl_severity = Level2
[IPQ Design Guidelines.22203]
vlog_severity = Level2
vlog_indexname = DFT.8-4
vhdl_indexname = DFT.8-4
vlog_val = BOTH
vlog_description = "reset signal used as data input"
vhdl_description = "reset signal used as data input"
vhdl_severity = Level2
vhdl_val = BOTH
[IPQ Design Guidelines.22204]
vlog_severity = Level2
vlog_indexname = DFT.8-5
vhdl_indexname = DFT.8-5
vlog_val = BOTH
vlog_description = "reset signal feeds into primary output"
vhdl_description = "reset signal feeds into primary output"
vhdl_severity = Level2
vhdl_val = BOTH
[IPQ Design Guidelines.22225]
vlog_severity = Level2
vlog_indexname = D.2/DFT.4/STA.2-2
vhdl_indexname = D.2/DFT.4/STA.2-2
vlog_val = TRUE
vlog_description = "Using synchronous design practices"
vhdl_description = "Using synchronous design practices"
vhdl_severity = Level2
vhdl_val = TRUE
[IPQ Design Guidelines.22227]
vlog_severity = Level2
vlog_indexname = DFT.8-3
vhdl_indexname = DFT.8-3
vlog_val = BOTH
vlog_description = "set signal used as data input"
vhdl_description = "set signal used as data input"
vhdl_severity = Level2
vhdl_val = BOTH
[IPQ Design Guidelines.22228]
vlog_severity = Level2
vlog_indexname = DFT.8-6
vhdl_indexname = DFT.8-6
vlog_val = BOTH
vlog_description = "set signal feeds into primary output"
vhdl_description = "set signal feeds into primary output"
vhdl_severity = Level2
vhdl_val = BOTH
[IPQ Design Guidelines.22275]
vlog_severity = Level2
vlog_indexname = STA.3-5
vhdl_indexname = STA.3-5
vlog_description = "Simplify the register clock origin--separate clock generator"
vhdl_description = "Simplify the register clock origin--separate clock generator"
vhdl_severity = Level2
[IPQ Design Guidelines.22279]
vlog_severity = Level3
vlog_indexname = SYN.6~7-2
vhdl_indexname = SYN.6~7-2
vlog_val = "INPUT, OUTPUT"
vlog_description = "All unused module inputs must be driven, outputs should be connected"
vhdl_description = "All unused module inputs must be driven, outputs should be connected"
vhdl_severity = Level3
vhdl_val = "INPUT, OUTPUT"
[IPQ Design Guidelines.23003]
vlog_severity = Level2
vlog_indexname = DFT.3/STA.6/SYN.4
vhdl_indexname = DFT.3/STA.6/SYN.4
vlog_val = FALSE
vlog_description = "Specify code fragments for combinational logic completely"
vhdl_description = "Specify code fragments for combinational logic completely"
vhdl_severity = Level2
vhdl_val = FALSE
[IPQ Design Guidelines.23007]
vlog_severity = Level2
vlog_indexname = SYN.9
vhdl_indexname = 23007
vlog_val = IGNORE_IN_SEQ,FOLLOW_FULL_CASE_DIRECTIVE
vlog_description = "Incomplete case statements should have default case assignments"
vhdl_severity = Level2
[IPQ Design Guidelines.23011]
vlog_severity = Level3
vlog_indexname = SIM.3
vhdl_indexname = SIM.3
vlog_description = "Avoid missing sensitivity lists in combinational always block"
vhdl_description = "Avoid missing sensitivity lists in combinational always block"
vhdl_severity = Level3
[IPQ Design Guidelines.23013]
vlog_severity = Level3
vlog_indexname = SIM.4
vhdl_indexname = SIM.4
vlog_val = BOTH,IGNORE_PART_SEL
vlog_description = "Avoid redundant sensitivity lists"
vhdl_description = "Avoid redundant sensitivity lists"
vhdl_severity = Level3
vhdl_val = BOTH,IGNORE_PART_SEL
[IPQ Design Guidelines.23015]
vlog_severity = Level3
vlog_indexname = SIM.1
vhdl_indexname = 23015
vlog_val = BLOCKING,""
vlog_description = "Use non-blocking assignments in sequential always blocks"
vhdl_severity = Level2
[IPQ Design Guidelines.23016]
vlog_severity = Level3
vlog_indexname = SIM.2
vhdl_indexname = 23016
vlog_val = NONBLOCKING,FALSE
vlog_description = "Use blocking assignments in combinational always blocks"
vhdl_severity = Level2
[IPQ Design Guidelines.23021]
vlog_severity = Level3
vlog_indexname = SYN.5-1
vhdl_indexname = 23021
vlog_val = DESIGN,""
vlog_description = "Verilog primitives are prohibited"
vhdl_severity = Level2
[IPQ Design Guidelines.23027]
vlog_severity = Level3
vlog_indexname = SYN.1.6-1
vhdl_indexname = SYN.1.6-1
vlog_val = IGNORE_SUBPROG
vlog_description = "Loop must be in a static range"
vhdl_description = "Loop must be in a static range"
vhdl_severity = Level3
vhdl_val = IGNORE_SUBPROG
[IPQ Design Guidelines.23045]
vlog_severity = Level3
vlog_indexname = SYN.1.4-2
vhdl_indexname = 23045
vlog_description = "Data type of time is prohibited"
vhdl_severity = Level2
[IPQ Design Guidelines.23047]
vlog_severity = Level3
vlog_indexname = SYN.1.4-1
vhdl_indexname = SYN.1.4-1
vlog_description = "Data type of real is prohibited"
vhdl_description = "Data type of real is prohibited"
vhdl_severity = Level3
[IPQ Design Guidelines.23051]
vlog_severity = Level3
vlog_indexname = SYN.1.4-3
vhdl_indexname = 23051
vlog_description = "Data type of event is prohibited"
vhdl_severity = Level2
[IPQ Design Guidelines.23053]
vlog_severity = Level3
vlog_indexname = SYN.5-2
vhdl_indexname = 23053
vlog_description = "UDP instance not synthesizable"
vhdl_severity = Level2
[IPQ Design Guidelines.23057]
vlog_severity = Level3
vlog_indexname = SYN.1.1
vhdl_indexname = 23057
vlog_description = "Waveform statement are prohibited"
vhdl_severity = Level2
[IPQ Design Guidelines.23061]
vlog_severity = Level3
vlog_indexname = SYN.5-3
vhdl_indexname = 23061
vlog_description = "UDP not synthesizable"
vhdl_severity = Level2
[IPQ Design Guidelines.23075]
vlog_severity = Level3
vlog_indexname = SYN.1.3-2
vhdl_indexname = 23075
vlog_description = "# delay statements are prohibited"
vhdl_severity = Level2
[IPQ Design Guidelines.23089]
vlog_severity = Level3
vlog_indexname = SIM.7/SYN.1.3-3
vhdl_indexname = 23089
vlog_description = "Avoid using delayed assignments"
vhdl_severity = Level2
[IPQ Design Guidelines.23095]
vlog_severity = Level3
vlog_indexname = SYN.1.3-1
vhdl_indexname = 23095
vlog_description = "Wait statements are prohibited"
vhdl_severity = Level2
[IPQ Design Guidelines.23103]
vlog_severity = Level3
vlog_indexname = SYN.1.2
vhdl_indexname = 23103
vlog_description = "System task for simulation (e.g. $display, $monitor, $printf, ) are prohibited"
vhdl_severity = Level2
[IPQ Design Guidelines.23121]
vlog_severity = Level2
vlog_indexname = D.5.1/SIM.5
vhdl_indexname = D.5.1/SIM.5
vlog_val = BOTH
vlog_description = "Initialize control storage elements"
vhdl_description = "Initialize control storage elements"
vhdl_severity = Level2
vhdl_val = BOTH
[IPQ Design Guidelines.23131]
vlog_severity = Level3
vlog_indexname = SIM.6
vhdl_indexname = 23131
vlog_val = CHECK_DEFAULT
vlog_description = "Do not assign signals don't care (x) value"
vhdl_severity = Level2
[IPQ Design Guidelines.23133]
vlog_severity = Level3
vlog_indexname = SYN.1.5
vhdl_indexname = 23133
vlog_description = "Only one clock per always sensitivity list"
vhdl_severity = Level2
[IPQ Design Guidelines.24001]
vlog_severity = Level3
vlog_indexname = NC.18
vhdl_indexname = 24001
vlog_description = "VHDL keywords are prohibited"
vhdl_severity = Level2
[IPQ Design Guidelines.24007]
vlog_severity = Level3
vlog_indexname = NC.5
vhdl_indexname = 24007
vlog_val = CHECK_ALL
vlog_description = "Names can not be distinguishable in letter case only"
vhdl_severity = Level2
[IPQ Design Guidelines.24019]
vlog_severity = Level2
vlog_indexname = SYN.2
vhdl_indexname = SYN.2
vlog_description = "Avoid any embedded synthesis scripts"
vhdl_description = "Avoid any embedded synthesis scripts"
vhdl_severity = Level2
[IPQ Design Guidelines.25003]
vlog_severity = Level1
vlog_indexname = DFT.10-3
vhdl_indexname = DFT.10-3
vlog_val = "CHECK_TOP_SIGNAL, CHECK_THROUGH_HIERARCHY"
vlog_description = "Avoid floating output"
vhdl_description = "Avoid floating output"
vhdl_severity = Level1
vhdl_val = "CHECK_TOP_SIGNAL, CHECK_THROUGH_HIERARCHY"
[IPQ Design Guidelines.25015]
vlog_severity = Level2
vlog_indexname = D.1.1
vhdl_indexname = D.1.1
vlog_description = "Output signals must be registered"
vhdl_description = "Output signals must be registered"
vhdl_severity = Level2
[IPQ Design Guidelines.27235]
vlog_severity = Level2
vlog_indexname = NC.9-4
vhdl_indexname = NC.9-4
vlog_val = CASE_LOWER
vlog_description = "Instances names are lowercase letters"
vhdl_description = "Instances names are lowercase letters"
vhdl_severity = Level2
vhdl_val = CASE_LOWER
[IPQ Design Guidelines.27287]
vlog_severity = Level2
vlog_indexname = NC.9-1
vhdl_indexname = 27287
vlog_val = [a-z]+
vlog_description = "Signals names are lowercase letters"
vhdl_severity = Level2
[IPQ Design Guidelines.27288]
vlog_severity = Level2
vlog_indexname = NC.19-1
vhdl_indexname = 27288
vlog_val = 1,32
vlog_description = "The length of signal names does not exceed 32 characters"
vhdl_severity = Level2
[IPQ Design Guidelines.27299]
vlog_severity = Level2
vlog_indexname = NC.9-2
vhdl_indexname = NC.9-2
vlog_val = CASE_LOWER
vlog_description = "Functions names are lowercase letters"
vhdl_description = "Functions names are lowercase letters"
vhdl_severity = Level2
vhdl_val = CASE_LOWER
[IPQ Design Guidelines.27307]
vlog_severity = Level2
vlog_indexname = NC.9-3
vhdl_indexname = NC.9-3
vlog_val = CASE_LOWER
vlog_description = "Tasks names are lowercase letters"
vhdl_description = "Tasks names are lowercase letters"
vhdl_severity = Level2
vhdl_val = CASE_LOWER
[IPQ Design Guidelines.27371]
vlog_severity = Level2
vlog_indexname = SYN.3
vhdl_indexname = SYN.3
vlog_val = "parallel_case,full_case"
vlog_description = "Avoid full_case and parallel_case synthesis directive"
vhdl_description = "Avoid full_case and parallel_case synthesis directive"
vhdl_severity = Level2
vhdl_val = "parallel_case,full_case"
[IPQ Design Guidelines.27373]
vlog_severity = Level1
vlog_indexname = NC.14-2
vhdl_indexname = NC.14-2
vlog_val = SUFFIX,_ns
vlog_description = "For FSM variables, naming in <fsm_cs>, <fsm_ns>"
vhdl_description = "For FSM variables, naming in <fsm_cs>, <fsm_ns>"
vhdl_severity = Level1
vhdl_val = SUFFIX,_ns
[IPQ Design Guidelines.27375]
vlog_severity = Level2
vlog_indexname = NC.4
vhdl_indexname = NC.4
vlog_val = ^[a-zA-Z][a-zA-Z0-9]*(_[a-zA-Z0-9]+)*
vlog_description = "Names starting with a letter"
vhdl_description = "Names starting with a letter"
vhdl_severity = Level2
vhdl_val = ^[a-zA-Z][a-zA-Z0-9]*(_[a-zA-Z0-9]+)*
[IPQ Design Guidelines.27411]
vlog_severity = Level3
vlog_indexname = CS.12
vhdl_indexname = 27411
vlog_description = "Use parameters for FSM state encoding"
vhdl_severity = Level2
[IPQ Design Guidelines.27413]
vlog_severity = Level2
vlog_indexname = STA.2-1
vhdl_indexname = STA.2-1
vlog_description = "Using synchronous design practices"
vhdl_description = "Using synchronous design practices"
vhdl_severity = Level2
[IPQ Design Guidelines.27417]
vlog_severity = Level2
vlog_indexname = SYN.8
vhdl_indexname = SYN.8
vlog_description = "Avoid top level glue logic"
vhdl_description = "Avoid top level glue logic"
vhdl_severity = Level2
[IPQ Design Guidelines.29001]
vlog_severity = Level2
vlog_indexname = NC.9-6
vhdl_indexname = 29001
vlog_description = "udpdefn name lower case"
vhdl_severity = Level2
[IPQ Design Guidelines.29002]
vlog_severity = Level2
vlog_indexname = NC.22
vhdl_indexname = 29002
vlog_description = "Instance names must be identical to the module name."
vhdl_severity = Level2
[IPQ Design Guidelines.29003]
vlog_severity = Level2
vhdl_severity = Level2
[IPQ Design Guidelines.29004]
vlog_severity = Level2
vlog_val = .*GTECH.*
vhdl_severity = Level2
vhdl_val = .*GTECH.*
[IPQ Design Guidelines.29005]
vlog_severity = Level2
vlog_val = 3
vhdl_severity = Level2
vhdl_val = 3
[IPQ Design Guidelines.29006]
vlog_severity = Level2
vlog_val = 2
vhdl_severity = Level2
vhdl_val = 2
[IPQ Design Guidelines.29100]
vlog_severity = Level2
vlog_indexname = CS.5
vhdl_indexname = 29100
vlog_description = "Preserve port order"
vhdl_severity = Level2
[IPQ Design Guidelines.29101]
vlog_severity = Level1
vlog_indexname = CS.6
vhdl_indexname = 29101
vlog_description = "Declare all internal nets in one section"
vhdl_severity = Level2
[IPQ Design Guidelines.29102]
vlog_severity = Level1
vlog_indexname = COM.3
vhdl_indexname = 29102
vlog_val = "always, assign, function, task"
vlog_description = "Use comments for functional sections"
vhdl_severity = Level2
vhdl_val = "always, assign, function, task"
[IPQ Design Guidelines.29103]
vlog_severity = Level1
vlog_indexname = COM.4
vhdl_indexname = 29103
vlog_description = "Use one-line comments instead of mulltiple-line comments"
vhdl_severity = Level2
[IPQ Design Guidelines.29104]
vlog_severity = Level2
vlog_indexname = COM.5
vhdl_indexname = 29104
vlog_description = "Use comments for cell instantiations"
vhdl_severity = Level2
[IPQ Design Guidelines.29105]
vlog_severity = Level1
vlog_indexname = COM.7
vhdl_indexname = 29105
vlog_description = "Use comments for synthesis directives"
vhdl_severity = Level2
[IPQ Design Guidelines.29106]
vlog_severity = Level2
vlog_indexname = FH.1~4
vhdl_indexname = 29106
vlog_val = file_header.tmpl
vlog_description = "Check file header format"
vhdl_severity = Level2
vhdl_val = file_header.tmpl
[IPQ Design Guidelines.29107]
vlog_severity = Level1
vlog_indexname = COM.8
vhdl_indexname = 29107
vlog_description = "Use comments for compiler directives"
vhdl_severity = Level2
[IPQ Design Guidelines.29108]
vlog_severity = Level2
vlog_val = "always, assign, function, initial, specify, task"
vhdl_severity = Level2
vhdl_val = "always, assign, function, initial, specify, task"
[IPQ Design Guidelines.29109]
vlog_severity = Level2
vlog_indexname = NC.8-2
vhdl_indexname = 29109
vlog_description = "Text macros are uppercase letters"
vhdl_severity = Level2
[IPQ Design Guidelines.29110]
vlog_severity = Level2
vlog_indexname = NC.7-1
vhdl_indexname = 29110
vlog_description = "Use consistent signal names throughout the hierarchy"
vhdl_severity = Level2
[IPQ Design Guidelines.29111]
vlog_severity = Level2
vlog_indexname = FH.5~7
vhdl_indexname = 29111
vlog_val = construct_header.tmpl
vlog_description = "Check construct header format"
vhdl_severity = Level2
vhdl_val = construct_header.tmpl
[IPQ Design Guidelines.29112]
vlog_severity = Level2
vlog_val = "BitNegOp, EqOp, NotEqOp"
vhdl_severity = Level2
vhdl_val = "BitNegOp, EqOp, NotEqOp"
[IPQ Design Guidelines.29113]
vlog_severity = Level2
vhdl_severity = Level2
[IPQ Design Guidelines.29114]
vlog_severity = Level2
vhdl_severity = Level2
[IPQ Design Guidelines.29115]
vlog_severity = Level2
vhdl_severity = Level2
[IPQ Design Guidelines.29116]
vlog_severity = Level2
vhdl_severity = Level2
[IPQ Design Guidelines.29118]
vlog_severity = Level2
vhdl_severity = Level2
[IPQ Design Guidelines.29201]
vlog_severity = Level2
vhdl_severity = Level2
[IPQ Design Guidelines.29204]
vlog_severity = Level1
vhdl_severity = Level2
[IPQ Design Guidelines.29206]
vlog_severity = Level2
vhdl_severity = Level2
[IPQ Design Guidelines.29211]
vlog_severity = Level2
vhdl_severity = Level2
[IPQ Design Guidelines.29212]
vlog_severity = Level2
vhdl_severity = Level2
[IPQ Design Guidelines.29801]
vlog_severity = Level3
vhdl_severity = Level2
[IPQ Design Guidelines.29802]
vlog_severity = Level2
vhdl_severity = Level2
[IPQ Design Guidelines.29803]
vlog_severity = Level3
vhdl_severity = Level2
[IPQ Design Guidelines.29804]
vlog_severity = Level2
vlog_val = 200
vhdl_severity = Level2
vhdl_val = 200
[IPQ Design Guidelines.29805]
vlog_severity = Level3
vhdl_severity = Level2
[IPQ Design Guidelines.29806]
vlog_severity = Level3
vhdl_severity = Level2
[IPQ Design Guidelines.29807]
vlog_severity = Level3
vhdl_severity = Level2
[IPQ Design Guidelines.29808]
vlog_severity = Level2
vhdl_severity = Level2
[IPQ Design Guidelines.29809]
vlog_severity = Level3
vhdl_severity = Level2
[IPQ Design Guidelines.29810]
vlog_severity = Level3
vhdl_severity = Level2
[IPQ Design Guidelines.29811]
vlog_severity = Level3
vhdl_severity = Level2
[IPQ Design Guidelines.29812]
vlog_severity = Level3
vhdl_severity = Level2
[IPQ Design Guidelines.29813]
vlog_severity = Level2
vhdl_severity = Level2
[IPQ Design Guidelines.29814]
vlog_severity = Level2
vhdl_severity = Level2
[IPQ Design Guidelines.29815]
vlog_severity = Level2
vlog_val = CHECK_CONDEXPR
vhdl_severity = Level2
vhdl_val = CHECK_CONDEXPR
[IPQ Design Guidelines.29816]
vlog_severity = Level2
vhdl_severity = Level2
[IPQ Design Guidelines.29817]
vlog_severity = Level3
vhdl_severity = Level2
[IPQ Design Guidelines.29818]
vlog_severity = Level3
vhdl_severity = Level2
[IPQ Design Guidelines.29819]
vlog_severity = Level3
vhdl_severity = Level2
[IPQ Design Guidelines.29820]
vlog_severity = Level3
vhdl_severity = Level2
[IPQ Design Guidelines.29821]
vlog_severity = Level2
vhdl_severity = Level2
[IPQ Design Guidelines.29822]
vlog_severity = Level2
vhdl_severity = Level2
[IPQ Design Guidelines.29823]
vlog_severity = Level3
vhdl_severity = Level2
[IPQ Design Guidelines.Coding Style]
22003 = Enable Enable TRUE TRUE
22004 = Enable Enable TRUE TRUE
22008 = Enable NONE TRUE NONE
22021 = Enable Enable TRUE TRUE
22023 = Enable Enable TRUE TRUE
22025 = Enable Enable TRUE TRUE
22027 = Enable Enable TRUE TRUE
22029 = Enable Enable TRUE TRUE
22031 = Disable Disable TRUE TRUE
22043 = Enable Enable TRUE TRUE
22063 = Enable Enable TRUE TRUE
22091 = Enable NONE TRUE NONE
22161 = Enable NONE TRUE NONE
27411 = Enable NONE TRUE NONE
29100 = Enable NONE TRUE NONE
29101 = Enable NONE TRUE NONE
[IPQ Design Guidelines.Comments]
22032 = Enable Enable TRUE TRUE
22038 = Enable Enable TRUE TRUE
29102 = Enable NONE TRUE NONE
29103 = Disable NONE TRUE NONE
29104 = Enable NONE TRUE NONE
29105 = Enable NONE TRUE NONE
29107 = Enable NONE TRUE NONE
[IPQ Design Guidelines.Design For Test]
22002 = Enable Enable TRUE TRUE
22007 = Enable Enable TRUE TRUE
22011 = Enable Enable TRUE TRUE
22020 = Enable Enable TRUE TRUE
22053 = Enable Enable TRUE TRUE
22054 = Enable Enable TRUE TRUE
22055 = Enable Enable TRUE TRUE
22056 = Enable Enable TRUE TRUE
22057 = Enable Enable TRUE TRUE
22127 = Enable Enable TRUE TRUE
22130 = Enable Enable TRUE TRUE
22131 = Enable Enable TRUE TRUE
22165 = Enable Enable TRUE TRUE
22167 = Enable Enable TRUE TRUE
22203 = Enable Enable TRUE TRUE
22204 = Enable Enable TRUE TRUE
22227 = Enable Enable TRUE TRUE
22228 = Enable Enable TRUE TRUE
23003 = Enable Enable TRUE TRUE
25003 = Enable Enable TRUE TRUE
[IPQ Design Guidelines.Design Style]
22053 = Enable Enable TRUE TRUE
22054 = Enable Enable TRUE TRUE
22055 = Enable Enable TRUE TRUE
22131 = Enable Enable TRUE TRUE
22132 = Enable Enable TRUE TRUE
25015 = Enable Enable TRUE TRUE
[IPQ Design Guidelines.File Header]
29106 = Enable NONE TRUE NONE
29111 = Enable NONE TRUE NONE
[IPQ Design Guidelines.Naming Convention]
21001 = Enable Enable TRUE TRUE
21005 = Enable Enable TRUE TRUE
21007 = Enable Enable TRUE TRUE
21009 = Enable Enable TRUE TRUE
21013 = Enable Enable TRUE TRUE
21014 = Enable Enable TRUE TRUE
21015 = Enable Enable TRUE TRUE
21019 = Enable Enable TRUE TRUE
21020 = Enable Enable TRUE TRUE
21023 = Disable Disable TRUE TRUE
21029 = Enable Enable TRUE TRUE
21031 = Enable Enable TRUE TRUE
21041 = Enable Enable TRUE TRUE
21043 = Enable Enable TRUE TRUE
21044 = Enable Enable TRUE TRUE
21057 = Enable Enable TRUE TRUE
24001 = Enable NONE TRUE NONE
24007 = Enable NONE TRUE NONE
27235 = Enable Enable TRUE TRUE
27287 = Enable NONE TRUE NONE
27288 = Enable NONE TRUE NONE
27299 = Enable Enable TRUE TRUE
27307 = Enable Enable TRUE TRUE
27373 = Enable Enable TRUE TRUE
27375 = Enable Enable TRUE TRUE
29001 = Enable NONE TRUE NONE
29002 = Enable NONE TRUE NONE
29109 = Enable NONE TRUE NONE
29110 = Enable NONE TRUE NONE
[IPQ Design Guidelines.Simulation]
23011 = Enable Enable TRUE TRUE
23013 = Enable Enable TRUE TRUE
23015 = Enable NONE TRUE NONE
23016 = Enable NONE TRUE NONE
23089 = Enable NONE TRUE NONE
23121 = Enable Enable TRUE TRUE
23131 = Enable NONE TRUE NONE
[IPQ Design Guidelines.Static Timing Analysis]
22011 = Enable Enable TRUE TRUE
22053 = Enable Enable TRUE TRUE
22054 = Enable Enable TRUE TRUE
22055 = Enable Enable TRUE TRUE
22127 = Enable Enable TRUE TRUE
22130 = Enable Enable TRUE TRUE
22131 = Enable Enable TRUE TRUE
22225 = Enable Enable TRUE TRUE
22275 = Enable Enable TRUE TRUE
23003 = Enable Enable TRUE TRUE
27413 = Enable Enable TRUE TRUE
[IPQ Design Guidelines.Synthesis]
22082 = Enable Enable TRUE TRUE
22112 = Enable NONE TRUE NONE
22113 = Enable Enable TRUE TRUE
22279 = Enable Enable TRUE TRUE
23003 = Enable Enable TRUE TRUE
23007 = Enable NONE TRUE NONE
23021 = Enable NONE TRUE NONE
23027 = Enable Enable TRUE TRUE
23045 = Enable NONE TRUE NONE
23047 = Enable Enable TRUE TRUE
23051 = Enable NONE TRUE NONE
23053 = Enable NONE TRUE NONE
23057 = Enable NONE TRUE NONE
23061 = Enable NONE TRUE NONE
23075 = Enable NONE TRUE NONE
23089 = Enable NONE TRUE NONE
23095 = Enable NONE TRUE NONE
23103 = Enable NONE TRUE NONE
23133 = Enable NONE TRUE NONE
24019 = Enable Enable TRUE TRUE
27371 = Enable Enable TRUE TRUE
27417 = Enable Enable TRUE TRUE
[IPQ Design Guidelines.include]
1 = "Naming Convention" Enable TRUE
2 = "File Header" Enable TRUE
3 = "Comments" Enable TRUE
4 = "Coding Style" Enable TRUE
5 = "Synthesis" Enable TRUE
6 = "Static Timing Analysis" Enable TRUE
7 = "Simulation" Enable TRUE
8 = "Design For Test" Enable TRUE
9 = "Design Style" Enable TRUE
[RMM.21001]
vlog_severity = Level2
vlog_indexname = 5.2.1-G1-1
vhdl_indexname = 5.2.1-G1-1
vlog_val = CASE_LOWER
vlog_description = "Use lowercase letters for all signal names"
vhdl_description = "Use lowercase letters for all signal names"
vhdl_severity = Level2
vhdl_val = CASE_LOWER
[RMM.21003]
vlog_severity = Level2
vlog_indexname = 5.2.1-G1-2
vhdl_indexname = 5.2.1-G1-2
vlog_val = CASE_LOWER
vlog_description = "Use lowercase letters for all variable names"
vhdl_description = "Use lowercase letters for all variable names"
vhdl_severity = Level2
vhdl_val = CASE_LOWER
[RMM.21005]
vlog_severity = Level2
vlog_indexname = 5.2.1-G1-3
vhdl_indexname = 5.2.1-G1-3
vlog_val = CASE_LOWER
vlog_description = "Use lowercase letters for all port names"
vhdl_description = "Use lowercase letters for all port names"
vhdl_severity = Level2
vhdl_val = CASE_LOWER
[RMM.21013]
vlog_severity = Level2
vlog_indexname = 5.2.1-G5
vhdl_indexname = 5.2.1-G5
vlog_val = PREFIX,clk_
vlog_description = "User the name clk or prefix clk for the clock signals."
vhdl_description = "User the name clk or prefix clk for the clock signals."
vhdl_severity = Level2
vhdl_val = PREFIX,clk_
[RMM.21015]
vlog_severity = Level2
vlog_indexname = 5.2.1-G9
vhdl_indexname = 5.2.1-G9
vlog_val = PREFIX,rst_
vlog_description = "Name or prefix rst used for reset signals"
vhdl_description = "Name or prefix rst used for reset signals"
vhdl_severity = Level2
vhdl_val = PREFIX,rst_
[RMM.21020]
vlog_severity = Level2
vlog_indexname = 5.2.1-G7
vhdl_indexname = 5.2.1-G7
vlog_val = SUFFIX,_n
vlog_description = "For active low signal, end the signal name with an underscore followed by a lowercase character"
vhdl_description = "For active low signal, end the signal name with an underscore followed by a lowercase character"
vhdl_severity = Level2
vhdl_val = SUFFIX,_n
[RMM.21023]
vlog_severity = Level2
vlog_indexname = 5.2.1-G10
vhdl_indexname = 5.2.1-G10
vlog_val = ZERO_BOUND,DOWN_TO
vlog_description = "Use desending bit order with zero bound in range declaration"
vhdl_description = "Use desending bit order with zero bound in range declaration"
vhdl_severity = Level2
vhdl_val = ZERO_BOUND,DOWN_TO
[RMM.21025]
vlog_severity = Level2
vlog_indexname = 5.2.1-G11
vhdl_indexname = 21025
vlog_val = IGNORE_LIB_CELL
vlog_description = "Same name or similar names, for ports and signals that are connected."
vhdl_severity = Level2
[RMM.21027]
vlog_severity = Level2
vlog_indexname = 5.2.1-G12-5
vhdl_indexname = 5.2.1-G12-5
vlog_val = SUFFIX,_r
vlog_description = "use suffix '_r' for register output signal name"
vhdl_description = "use suffix '_r' for register output signal name"
vhdl_severity = Level2
vhdl_val = SUFFIX,_r
[RMM.21029]
vlog_severity = Level2
vlog_indexname = 5.2.1-G12-1
vhdl_indexname = 5.2.1-G12-1
vlog_val = SUFFIX,_a
vlog_description = "use suffix '_a' for asynchronous signal name"
vhdl_description = "use suffix '_a' for asynchronous signal name"
vhdl_severity = Level2
vhdl_val = SUFFIX,_a
[RMM.21031]
vlog_severity = Level2
vlog_indexname = 5.2.1-G12-2
vhdl_indexname = 5.2.1-G12-2
vlog_val = SUFFIX,_z
vlog_description = "use suffix '_z' for tri-state internal signal name"
vhdl_description = "use suffix '_z' for tri-state internal signal name"
vhdl_severity = Level2
vhdl_val = SUFFIX,_z
[RMM.21035]
vlog_severity = Level2
vlog_indexname = 5.2.1-G12-4
vhdl_indexname = 5.2.1-G12-4
vlog_val = SUFFIX,_nxt
vlog_description = "use suffix '_nxt' for the name of data before being registered"
vhdl_description = "use suffix '_nxt' for the name of data before being registered"
vhdl_severity = Level2
vhdl_val = SUFFIX,_nxt
[RMM.21041]
vlog_severity = Level2
vlog_indexname = 5.2.1-G2-1
vhdl_indexname = 5.2.1-G2-1
vlog_val = CASE_UPPER
vlog_description = "Use uppercase letters for names of parameter"
vhdl_description = "Use uppercase letters for names of GENERIC"
vhdl_severity = Level2
vhdl_val = CASE_UPPER
[RMM.21049]
vlog_severity = Level2
vlog_indexname = 5.2.15.G1
vhdl_indexname = 5.2.15.G1
vlog_val = SUFFIX,_PROC
vlog_description = "Each process block labeled <name>_PROC"
vhdl_description = "Each process block labeled <name>_PROC"
vhdl_severity = Level2
vhdl_val = SUFFIX,_PROC
[RMM.21050]
vlog_severity = Level2
vlog_indexname = 5.2.15-R1
vhdl_indexname = 5.2.15-R1
vlog_val = "INITIAL, ALWAYS, ALWAYS_COMB, ALWAYS_FF, ALWAYS_LATCH, GENERATE, IF"
vlog_description = "Each process block labeled with meaningful name"
vhdl_description = "Each process block labeled with meaningful name"
vhdl_severity = Level2
vhdl_val = ""
[RMM.21051]
vlog_severity = Level2
vlog_indexname = 5.2.15-G2
vhdl_indexname = 5.2.15-G2
vlog_val = PREFIX,U_
vlog_description = "Each instance labeled U_<name>."
vhdl_description = "Each instance labeled U_<name>."
vhdl_severity = Level2
vhdl_val = PREFIX,U_
[RMM.21057]
vlog_severity = Level2
vlog_indexname = 5.2.1-G6
vhdl_indexname = 5.2.1-G6
vlog_val = PREFIX
vlog_description = "Use the same name for all clock signals that are driven from the same clock source"
vhdl_description = "Use the same name for all clock signals that are driven from the same clock source"
vhdl_severity = Level2
vhdl_val = PREFIX
[RMM.22011]
vlog_severity = Level2
vlog_indexname = 5.5.4-G1
vhdl_indexname = 5.5.4-G1
vlog_val = SYNC
vlog_description = "No combinational feedback"
vhdl_description = "No combinational feedback"
vhdl_severity = Level2
vhdl_val = SYNC
[RMM.22023]
vlog_severity = Level2
vlog_indexname = 5.2.6-R1
vhdl_indexname = 5.2.6-R1
vlog_description = "Use separate line for each HDL statement"
vhdl_description = "Use separate line for each HDL statement"
vhdl_severity = Level2
[RMM.22025]
vlog_severity = Level2
vlog_indexname = 5.2.7-G1
vhdl_indexname = 5.2.7-G1
vlog_val = 72
vlog_description = "Keep the line length to 72 characters or less"
vhdl_description = "Keep the line length to 72 characters or less"
vhdl_severity = Level2
vhdl_val = 72
[RMM.22027]
vlog_severity = Level2
vlog_indexname = 5.2.8-G1
vhdl_indexname = 5.2.8-G1
vlog_val = 2,"FIRST_INDENT, BEGIN_INDENT"
vlog_description = "User indentation with consistent spaces number to improve the readability"
vhdl_description = "User indentation with consistent spaces number to improve the readability"
vhdl_severity = Level2
vhdl_val = 2,"FIRST_INDENT, BEGIN_INDENT"
[RMM.22029]
vlog_severity = Level2
vlog_indexname = 5.2.8-G2
vhdl_indexname = 5.2.8-G2
vlog_val = CHECK_WHOLE
vlog_description = "Avoid using tabs"
vhdl_description = "Avoid using tabs"
vhdl_severity = Level2
vhdl_val = CHECK_WHOLE
[RMM.22031]
vlog_severity = Level2
vlog_indexname = 5.2.5-G1-1
vhdl_indexname = 5.2.5-G1-1
vlog_description = "Use comments to explain ports"
vhdl_description = "Use comments to explain ports"
vhdl_severity = Level2
[RMM.22033]
vlog_severity = Level2
vlog_indexname = 5.2.11-G1
vhdl_indexname = 5.2.11-G1
vlog_val = FALSE,"INPUT, OUTPUT, INOUT, BUFFER, LINKAGE"
vlog_description = "Blank line between the input and output ports to improve readability"
vhdl_description = "Blank line between the input and output ports to improve readability"
vhdl_severity = Level2
vhdl_val = FALSE,"INPUT, OUTPUT, INOUT, BUFFER, LINKAGE"
[RMM.22035]
vlog_severity = Level2
vlog_indexname = 5.2.10-G2-1
vhdl_indexname = 5.2.10-G2-1
vlog_val = "INPUT, OUTPUT, INOUT, BUFFER, LINKAGE","CLOCK, RESET, SET, ENABLE, TE, CONTROL"
vlog_description = "Declare ports in a logical order"
vhdl_description = "Declare ports in a logical order"
vhdl_severity = Level2
vhdl_val = "INPUT, OUTPUT, INOUT, BUFFER, LINKAGE","CLOCK, RESET, SET, ENABLE, TE, CONTROL"
[RMM.22038]
vlog_severity = Level2
vlog_indexname = 5.2.5-G1-2
vhdl_indexname = 5.2.5-G1-2
vlog_val = IGNORE_COMMENT
vlog_description = "Use comments to explain signals and variables"
vhdl_description = "Use comments to explain signals and variables"
vhdl_severity = Level2
vhdl_val = IGNORE_COMMENT
[RMM.22039]
vlog_severity = Level2
vlog_indexname = 5.2.10-R1
vhdl_indexname = 5.2.10-R1
vlog_description = "Declare ports in a logical order"
vhdl_description = "Declare ports in a logical order"
vhdl_severity = Level2
[RMM.22043]
vlog_severity = Level2
vlog_indexname = 5.2.11-R1-1
vhdl_indexname = 5.2.11-R1-1
vlog_val = MODULE
vlog_description = "Use explicit mapping for ports"
vhdl_description = "Use explicit mapping for ports"
vhdl_severity = Level2
vhdl_val = MODULE
[RMM.22044]
vlog_severity = Level2
vlog_indexname = 5.2.11-R1-2
vhdl_indexname = 5.2.11-R1-2
vlog_description = "Use explicit mapping for parameter"
vhdl_description = "Use explicit mapping for generic"
vhdl_severity = Level2
[RMM.22049]
vlog_severity = Level2
vlog_indexname = 5.3.2-G1
vhdl_indexname = 5.3.2-G1
vlog_val = "ENTITY, ARCHITECTURE"
vlog_description = "No hard-coded numeric values in your design (with possible exception of 1 and 0)."
vhdl_description = "No hard-coded numeric values in your design (with possible exception of 1 and 0)."
vhdl_severity = Level2
vhdl_val = "ENTITY, ARCHITECTURE"
[RMM.22053]
vlog_severity = Level2
vlog_indexname = 5.4.3-G1
vhdl_indexname = 5.4.3-G1
vlog_description = "No gated clocks in design."
vhdl_description = "No gated clocks in design."
vhdl_severity = Level2
[RMM.22055]
vlog_severity = Level2
vlog_indexname = 5.4.2-G1
vhdl_indexname = 5.4.2-G1
vlog_description = "No clock buffers in design; inserted after synthesis in physical design stage."
vhdl_description = "No clock buffers in design; inserted after synthesis in physical design stage."
vhdl_severity = Level2
[RMM.22056]
vlog_severity = Level2
vlog_indexname = 5.4.6-G1-1
vhdl_indexname = 5.4.6-G1-1
vlog_val = BOTH
vlog_description = "No internally generated"
vhdl_description = "No internally generated"
vhdl_severity = Level2
vhdl_val = BOTH
[RMM.22063]
vlog_severity = Level2
vlog_indexname = 5.5.9-G1
vhdl_indexname = 5.5.9-G1
vlog_description = "describe state machines into two processes"
vhdl_description = "describe state machines into two processes"
vhdl_severity = Level2
[RMM.22067]
vlog_severity = Level2
vlog_indexname = 5.5.9-G3
vhdl_indexname = 5.5.9-G3
vlog_description = "FSM logic and non-FSM logic separated into different modules."
vhdl_description = "FSM logic and non-FSM logic separated into different modules."
vhdl_severity = Level2
[RMM.22131]
vlog_severity = Level2
vlog_indexname = 5.4.4-G1
vhdl_indexname = 5.4.4-G1
vlog_description = "No internally generated clocks in design."
vhdl_description = "No internally generated clocks in design."
vhdl_severity = Level2
[RMM.22225]
vlog_severity = Level3
vlog_indexname = 5.4.1-G1
vhdl_indexname = 5.4.1-G1
vlog_val = TRUE
vlog_description = "Avoid using both positive-edge and negative-edge triggered flip-flops in your design"
vhdl_description = "Avoid using both positive-edge and negative-edge triggered flip-flops in your design"
vhdl_severity = Level3
vhdl_val = TRUE
[RMM.22269]
vlog_severity = Level2
vlog_indexname = 5.6.3-G1
vhdl_indexname = 5.6.3-G1
vlog_val = SYNC,30
vlog_description = "Critical path logic isolated in a separate module from noncritical path logic"
vhdl_description = "Critical path logic isolated in a separate module from noncritical path logic"
vhdl_severity = Level2
vhdl_val = SYNC,30
[RMM.22271]
vlog_severity = Level2
vlog_indexname = 5.6.2-G1
vhdl_indexname = 5.6.2-G1
vlog_val = 10
vlog_description = "Related combinational logic placed together in the same module."
vhdl_description = "Related combinational logic placed together in the same module."
vhdl_severity = Level2
vhdl_val = 10
[RMM.22273]
vlog_severity = Level3
vlog_indexname = 5.4.5-G1-1
vhdl_indexname = 5.4.5-G1-1
vlog_description = "separate clock generate circuit in different modules"
vhdl_description = "separate clock generate circuit in different modules"
vhdl_severity = Level3
[RMM.22275]
vlog_severity = Level3
vlog_indexname = 5.4.6-G2
vhdl_indexname = 5.4.6-G2
vlog_description = "separate reset generate circuit into different modules"
vhdl_description = "separate reset generate circuit into different modules"
vhdl_severity = Level3
[RMM.23003]
vlog_severity = Level2
vlog_indexname = 5.5.2-G1
vhdl_indexname = 5.5.2-G1
vlog_val = FALSE
vlog_description = "No latch inference"
vhdl_description = "No latch inference"
vhdl_severity = Level2
vhdl_val = FALSE
[RMM.23011]
vlog_severity = Level3
vlog_indexname = 5.5.5-G1
vhdl_indexname = 5.5.5-G1
vlog_description = "Complete sensitivity list in each process (VHDL) or always (Verilog) blocks."
vhdl_description = "Complete sensitivity list in each process (VHDL) or always (Verilog) blocks."
vhdl_severity = Level3
[RMM.23013]
vlog_severity = Level2
vlog_indexname = 5.5.5-G2
vhdl_indexname = 5.5.5-G2
vlog_val = BOTH,IGNORE_PART_SEL
vlog_description = "Only necessary signals in each process sensitivity lists"
vhdl_description = "Only necessary signals in each process sensitivity lists"
vhdl_severity = Level2
vhdl_val = BOTH,IGNORE_PART_SEL
[RMM.23015]
vlog_severity = Level3
vlog_indexname = 5.5.6-G1
vhdl_indexname = 23015
vlog_val = BLOCKING,REG_INFER_ASSIGN
vlog_description = "nonblocking assignments always used in sequencial blocks for synthesis"
vhdl_severity = Level2
[RMM.23017]
vlog_severity = Level2
vlog_indexname = 5.5.8.1
vhdl_indexname = 5.5.8.1
vlog_val = CHECK_BOTH
vlog_description = "Case statements used rather than an if-then-else statement wherever possible"
vhdl_description = "Case statements used rather than an if-then-else statement wherever possible"
vhdl_severity = Level2
vhdl_val = CHECK_BOTH
[RMM.23021]
vlog_severity = Level2
vlog_indexname = 5.6.8-G1
vhdl_indexname = 23021
vlog_val = NON_LEAF,""
vlog_description = "No instantiated gate-level logic at the top level of the design hierarchy."
vhdl_severity = Level2
[RMM.23043]
vlog_severity = Level2
vlog_indexname = 5.4.6-G1-1
vhdl_indexname = 5.4.6-G1-1
vlog_val = "CLOCK, RESET, SET, LATCH_ENABLE, TRI_ENABLE"
vlog_description = "No conditional resets"
vhdl_description = "No conditional resets"
vhdl_severity = Level2
vhdl_val = "CLOCK, RESET, SET, LATCH_ENABLE, TRI_ENABLE"
[RMM.23121]
vlog_severity = Level3
vlog_indexname = 5.5.1-G1-2
vhdl_indexname = 5.5.1-G1-2
vlog_val = BOTH
vlog_description = "Use the design's reset signal to initialize registered signals."
vhdl_description = "Use the design's reset signal to initialize registered signals."
vhdl_severity = Level3
vhdl_val = BOTH
[RMM.24001]
vlog_severity = Level2
vlog_indexname = 5.2.9-G1-1
vhdl_indexname = 24001
vlog_description = "Do not use VHDL reserved words for names in RTL source files"
vhdl_severity = Level2
[RMM.24003]
vlog_severity = Level2
vhdl_description = "Do not user verilog reserved words for names in RTL source files."
vhdl_severity = Level2
[RMM.24009]
vlog_severity = Level2
vlog_indexname = 5.2.15-R3
vhdl_indexname = 5.2.15-R3
vlog_description = "Signal, variable, or entity names are not duplicated."
vhdl_description = "Signal, variable, or entity names are not duplicated."
vhdl_severity = Level2
[RMM.25015]
vlog_severity = Level2
vlog_indexname = 5.6.1-G1
vhdl_indexname = 5.6.1-G1
vlog_description = "For each block of a hierarchical design, all output signals should be registered"
vhdl_description = "For each block of a hierarchical design, all output signals should be registered"
vhdl_severity = Level2
[RMM.27063]
vlog_severity = Level2
vhdl_description = "Use uppercase letters for names of literal"
vhdl_severity = Level2
vhdl_val = CASE_UPPER
[RMM.27069]
vlog_severity = Level2
vhdl_description = "use Only IEEE Standard Types"
vhdl_severity = Level2
[RMM.27071]
vlog_severity = Level2
vhdl_description = "If VHDL, then types bit or bit_vector not used."
vhdl_severity = Level2
[RMM.27083]
vlog_severity = Level2
vhdl_description = "std_logic and std_logic_vector packages used rather than std_ulogic and std_ulogic_vector."
vhdl_severity = Level2
vhdl_val = RESOLVED
[RMM.27143]
vlog_severity = Level2
vhdl_description = "Do not use BLOCK constructs"
vhdl_severity = Level2
[RMM.27144]
vlog_severity = Level2
vhdl_description = "do not use generate statements."
vhdl_severity = Level2
[RMM.27181]
vlog_severity = Level2
vhdl_description = "use signals instead of variables for synthesizable RTL."
vhdl_severity = Level2
[RMM.27259]
vlog_severity = Level2
vhdl_description = "Use uppercase letters for names of CONSTANT"
vhdl_severity = Level2
vhdl_val = CASE_UPPER
[RMM.27273]
vlog_severity = Level2
vlog_indexname = 5.2.1-G4
vhdl_indexname = 5.2.1-G4
vlog_val = 3,16
vlog_description = "Use short but descriptive names for parameters"
vhdl_description = "Use short but descriptive names for GENERIC"
vhdl_severity = Level2
vhdl_val = 3,16
[RMM.27524]
vlog_severity = Level2
vlog_indexname = 5.5.1-G1-3
vhdl_indexname = 5.5.1-G1-3
vhdl_description = "do not initialize the signal in the declaration;"
vhdl_severity = Level2
[RMM.Clocks and Resets]
22053 = Enable Enable TRUE TRUE
22055 = Enable Enable TRUE TRUE
22056 = Enable Enable TRUE TRUE
22131 = Enable Enable TRUE TRUE
22225 = Enable Enable TRUE TRUE
22273 = Enable Enable TRUE TRUE
22275 = Enable Enable TRUE TRUE
23043 = Enable Enable TRUE TRUE
[RMM.Coding Practice]
21001 = Enable Enable TRUE TRUE
21003 = Enable Enable TRUE TRUE
21005 = Enable Enable TRUE TRUE
21013 = Enable Enable TRUE TRUE
21015 = Enable Enable TRUE TRUE
21020 = Enable Enable TRUE TRUE
21023 = Enable Enable TRUE TRUE
21025 = Enable NONE TRUE NONE
21027 = Enable Enable TRUE TRUE
21029 = Enable Enable TRUE TRUE
21031 = Enable Enable TRUE TRUE
21035 = Enable Enable TRUE TRUE
21041 = Enable Enable TRUE TRUE
21049 = Enable Enable TRUE TRUE
21050 = Enable Enable TRUE TRUE
21051 = Enable Enable TRUE TRUE
21057 = Enable Enable TRUE TRUE
22023 = Enable Enable TRUE TRUE
22025 = Enable Enable TRUE TRUE
22027 = Enable Enable TRUE TRUE
22029 = Disable Disable TRUE TRUE
22031 = Enable Enable TRUE TRUE
22033 = Enable Enable TRUE TRUE
22035 = Enable Enable TRUE TRUE
22038 = Enable Enable TRUE TRUE
22039 = Enable Enable TRUE TRUE
22043 = Enable Enable TRUE TRUE
22044 = Enable Enable TRUE TRUE
24001 = Enable NONE TRUE NONE
24003 = NONE Enable NONE TRUE
24009 = Enable Enable TRUE TRUE
27063 = NONE Enable NONE TRUE
27259 = NONE Enable NONE TRUE
27273 = Enable Enable TRUE TRUE
[RMM.Coding for Portability]
22049 = Enable Enable TRUE TRUE
27069 = NONE Enable NONE TRUE
27071 = NONE Enable NONE TRUE
27083 = NONE Enable NONE TRUE
27143 = NONE Enable NONE TRUE
27144 = NONE Enable NONE TRUE
[RMM.Coding for Synthesis]
22011 = Enable Enable TRUE TRUE
22063 = Enable Enable TRUE TRUE
22067 = Enable Enable TRUE TRUE
23003 = Enable Enable TRUE TRUE
23011 = Enable Enable TRUE TRUE
23013 = Enable Enable TRUE TRUE
23015 = Enable NONE TRUE NONE
23017 = Enable Enable TRUE TRUE
23121 = Enable Enable TRUE TRUE
27181 = NONE Enable NONE TRUE
27524 = Enable Enable TRUE TRUE
[RMM.Partition for Synthesis]
22269 = Enable Enable TRUE TRUE
22271 = Enable Enable TRUE TRUE
23021 = Enable NONE TRUE NONE
25015 = Enable Enable TRUE TRUE
[RMM.include]
1 = "Coding Practice" Disable TRUE
2 = "Clocks and Resets" Enable TRUE
3 = "Coding for Synthesis" Enable TRUE
4 = "Coding for Portability" Enable TRUE
5 = "Partition for Synthesis" Enable TRUE
[RuleVersion]
Version = 20130.03
[nLint.16057]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.16651]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.21001]
vlog_severity = Level2
vlog_val = CASE_LOWER
vhdl_severity = Level2
vhdl_val = CASE_LOWER
[nLint.21003]
vlog_severity = Level2
vlog_val = CASE_LOWER
vhdl_severity = Level2
vhdl_val = CASE_LOWER
[nLint.21005]
vlog_severity = Level2
vlog_val = CASE_LOWER
vhdl_severity = Level2
vhdl_val = CASE_LOWER
[nLint.21007]
vlog_severity = Level2
vlog_val = 16
vhdl_severity = Level2
vhdl_val = 16
[nLint.21009]
vlog_severity = Level2
vlog_val = 16
vhdl_severity = Level2
vhdl_val = 16
[nLint.21011]
vlog_severity = Level2
vlog_val = 16
vhdl_severity = Level2
vhdl_val = 16
[nLint.21013]
vlog_severity = Level2
vlog_val = PREFIX,clk_
vhdl_severity = Level2
vhdl_val = PREFIX,clk_
[nLint.21014]
vlog_severity = Level2
vlog_val = SUFFIX,_lat
vhdl_severity = Level2
vhdl_val = SUFFIX,_lat
[nLint.21015]
vlog_severity = Level2
vlog_val = PREFIX,rst_
vhdl_severity = Level2
vhdl_val = PREFIX,rst_
[nLint.21017]
vlog_severity = Level2
vlog_val = PREFIX,set_
vhdl_severity = Level2
vhdl_val = PREFIX,set_
[nLint.21019]
vlog_severity = Level2
vlog_val = SUFFIX,_cs
vhdl_severity = Level2
vhdl_val = SUFFIX,_cs
[nLint.21020]
vlog_severity = Level2
vlog_val = SUFFIX,_n
vhdl_severity = Level2
vhdl_val = SUFFIX,_n
[nLint.21021]
vlog_severity = Level2
vlog_val = SUFFIX,_p
vhdl_severity = Level2
vhdl_val = SUFFIX,_p
[nLint.21022]
vlog_severity = Level2
vlog_val = "TRUE,RESET_LOW,rst_.*_n;FALSE,RESET_HIGH,rst_.*_p;TRUE,SET_LOW,set_.*_n;TRUE,SET_HIGH,set_.*_p;FALSE,LATCH_ENABLE_LOW,;FALSE,LATCH_ENABLE_HIGH,;FALSE,TRI_ENABLE_LOW,;FALSE,TRI_ENABLE_HIGH,"
vhdl_severity = Level2
vhdl_val = "TRUE,RESET_LOW,rst_.*_n;FALSE,RESET_HIGH,rst_.*_p;TRUE,SET_LOW,set_.*_n;TRUE,SET_HIGH,set_.*_p;FALSE,LATCH_ENABLE_LOW,;FALSE,LATCH_ENABLE_HIGH,;FALSE,TRI_ENABLE_LOW,;FALSE,TRI_ENABLE_HIGH,"
[nLint.21023]
vlog_severity = Level2
vlog_val = ZERO_BOUND,DOWN_TO
vhdl_severity = Level2
vhdl_val = ZERO_BOUND,DOWN_TO
[nLint.21025]
vlog_severity = Level2
vlog_val = IGNORE_LIB_CELL
vhdl_severity = Level2
[nLint.21027]
vlog_severity = Level2
vlog_val = SUFFIX,_r
vhdl_severity = Level2
vhdl_val = SUFFIX,_r
[nLint.21029]
vlog_severity = Level2
vlog_val = SUFFIX,_a
vhdl_severity = Level2
vhdl_val = SUFFIX,_a
[nLint.21031]
vlog_severity = Level2
vlog_val = SUFFIX,_z
vhdl_severity = Level2
vhdl_val = SUFFIX,_z
[nLint.21035]
vlog_severity = Level2
vlog_val = SUFFIX,_nxt
vhdl_severity = Level2
vhdl_val = SUFFIX,_nxt
[nLint.21041]
vlog_severity = Level2
vlog_val = CASE_UPPER
vhdl_severity = Level2
vhdl_val = CASE_UPPER
[nLint.21043]
vlog_severity = Level2
vlog_val = CHECK_ALL_MODULE
vhdl_severity = Level2
vhdl_val = CHECK_ALL_MODULE
[nLint.21044]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.21045]
vlog_severity = Level2
vlog_val = 8,3
vhdl_severity = Level2
vhdl_val = 8,3
[nLint.21047]
vlog_severity = Level2
vlog_val = "O,0;I,1,l"
vhdl_severity = Level2
[nLint.21049]
vlog_severity = Level2
vlog_val = SUFFIX,_PROC
vhdl_severity = Level2
vhdl_val = SUFFIX,_PROC
[nLint.21050]
vlog_severity = Level2
vlog_val = "INITIAL, ALWAYS, ALWAYS_COMB, ALWAYS_FF, ALWAYS_LATCH, GENERATE, IF"
vhdl_severity = Level2
vhdl_val = ""
[nLint.21051]
vlog_severity = Level2
vlog_val = PREFIX,U_
vhdl_severity = Level2
vhdl_val = PREFIX,U_
[nLint.21052]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.21053]
vlog_severity = Level2
vlog_val = PREFIX,gate_
vhdl_severity = Level2
[nLint.21055]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.21057]
vlog_severity = Level2
vlog_val = PREFIX
vhdl_severity = Level2
vhdl_val = PREFIX
[nLint.22001]
vlog_severity = Level3
vlog_val = IGNORE_FLOATING,IGNORE_TRISTATE
vhdl_severity = Level3
vhdl_val = IGNORE_FLOATING,IGNORE_TRISTATE
[nLint.22002]
vlog_severity = Level3
vhdl_severity = Level3
[nLint.22003]
vlog_severity = Level3
vlog_val = LHS_GE_RHS,VAR_GE_CON
vhdl_severity = Level3
vhdl_val = LHS_GE_RHS,VAR_GE_CON
[nLint.22004]
vlog_severity = Level3
vlog_val = VAR_GE_CON
vhdl_severity = Level3
vhdl_val = VAR_GE_CON
[nLint.22005]
vlog_severity = Level3
vlog_val = CONSTANT
vhdl_severity = Level3
vhdl_val = CONSTANT
[nLint.22006]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22007]
vlog_severity = Level2
vlog_val = "INPUT, OUTPUT"
vhdl_severity = Level2
vhdl_val = "INPUT, OUTPUT"
[nLint.22008]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22009]
vlog_severity = Level3
vhdl_severity = Level2
[nLint.22010]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22011]
vlog_severity = Level2
vlog_val = SYNC
vhdl_severity = Level2
vhdl_val = SYNC
[nLint.22012]
vlog_severity = Level2
vlog_val = VAR_EQ_CON
vhdl_severity = Level2
vhdl_val = VAR_EQ_CON
[nLint.22013]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22014]
vlog_severity = Level2
vlog_val = FALSE
vhdl_severity = Level2
vhdl_val = FALSE
[nLint.22015]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22016]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22017]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22018]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22019]
vlog_severity = Level3
vhdl_severity = Level2
[nLint.22020]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22021]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22022]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22023]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22024]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22025]
vlog_severity = Level2
vlog_val = 80
vhdl_severity = Level2
vhdl_val = 80
[nLint.22026]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22027]
vlog_severity = Level2
vlog_val = 2,"FIRST_INDENT, REPORT_ALL"
vhdl_severity = Level2
vhdl_val = 2,"FIRST_INDENT, BEGIN_INDENT"
[nLint.22029]
vlog_severity = Level2
vlog_val = CHECK_WHOLE
vhdl_severity = Level2
vhdl_val = CHECK_WHOLE
[nLint.22031]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22032]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22033]
vlog_severity = Level2
vlog_val = FALSE,"INPUT, OUTPUT, INOUT, BUFFER, LINKAGE"
vhdl_severity = Level2
vhdl_val = FALSE,"INPUT, OUTPUT, INOUT, BUFFER, LINKAGE"
[nLint.22035]
vlog_severity = Level2
vlog_val = "INPUT, OUTPUT, INOUT, BUFFER, LINKAGE","CLOCK, RESET, SET, ENABLE, TE, CONTROL"
vhdl_severity = Level2
vhdl_val = "INPUT, OUTPUT, INOUT, BUFFER, LINKAGE","CLOCK, RESET, SET, ENABLE, TE, CONTROL"
[nLint.22038]
vlog_severity = Level2
vlog_val = IGNORE_COMMENT
vhdl_severity = Level2
vhdl_val = IGNORE_COMMENT
[nLint.22039]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22041]
vlog_severity = Level2
vlog_val = IGNORE_ANSI_PORT
vhdl_severity = Level2
[nLint.22043]
vlog_severity = Level2
vlog_val = MODULE
vhdl_severity = Level2
vhdl_val = MODULE
[nLint.22044]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22045]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22049]
vlog_severity = Level2
vlog_val = "ENTITY, ARCHITECTURE"
vhdl_severity = Level2
vhdl_val = "ENTITY, ARCHITECTURE"
[nLint.22051]
vlog_severity = Level2
vlog_val = "PASS_THROUGH_BUFFER_ASSIGNMENT, PASS_THROUGH_EVEN_INVERTERS"
vhdl_severity = Level2
[nLint.22052]
vlog_severity = Level2
vlog_val = "PASS_THROUGH_BUFFER_ASSIGNMENT, PASS_THROUGH_EVEN_INVERTERS"
vhdl_severity = Level2
[nLint.22053]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22054]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22055]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22056]
vlog_severity = Level2
vlog_val = BOTH
vhdl_severity = Level2
vhdl_val = BOTH
[nLint.22057]
vlog_severity = Level2
vlog_val = BOTH
vhdl_severity = Level2
vhdl_val = BOTH
[nLint.22058]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22059]
vlog_severity = Level2
vlog_val = BOTH
vhdl_severity = Level2
vhdl_val = BOTH
[nLint.22061]
vlog_severity = Level2
vlog_val = CHECK_TYPE_DETAIL
vhdl_severity = Level2
vhdl_val = CHECK_TYPE_DETAIL
[nLint.22063]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22067]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22075]
vlog_severity = Level3
vhdl_severity = Level2
[nLint.22077]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22079]
vlog_severity = Level2
vlog_val = IGNORE_PARAMETER
vhdl_severity = Level2
vhdl_val = IGNORE_PARAMETER
[nLint.22082]
vlog_severity = Level2
vlog_val = "INPUT, OUTPUT, INOUT"
vhdl_severity = Level2
vhdl_val = "INPUT, OUTPUT, INOUT"
[nLint.22083]
vlog_severity = Level2
vlog_val = 32
vhdl_severity = Level2
vhdl_val = 32
[nLint.22084]
vlog_severity = Level3
vlog_val = DEF_GE_VAL
vhdl_severity = Level2
[nLint.22085]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22089]
vlog_severity = Level3
vhdl_severity = Level2
[nLint.22091]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22097]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22098]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22101]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22103]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22104]
vlog_severity = Level2
vlog_val = VAR_GE_CON
vhdl_severity = Level2
vhdl_val = VAR_GE_CON
[nLint.22105]
vlog_severity = Level2
vlog_val = ""
vhdl_severity = Level2
vhdl_val = ""
[nLint.22106]
vlog_severity = Level2
vlog_val = VAR_GE_CON
vhdl_severity = Level2
[nLint.22107]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22108]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22109]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22112]
vlog_severity = Level3
vhdl_severity = Level2
[nLint.22113]
vlog_severity = Level3
vhdl_severity = Level3
[nLint.22115]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22117]
vlog_severity = Level2
vlog_val = SYNC_ASYNC_COEXIST
vhdl_severity = Level2
vhdl_val = BOTH
[nLint.22118]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22119]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22120]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22121]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22122]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22123]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22124]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22125]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22126]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22127]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22128]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22129]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22130]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22131]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22132]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22133]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22134]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22139]
vlog_severity = Level3
vhdl_severity = Level2
[nLint.22149]
vlog_severity = Level1
vhdl_severity = Level2
[nLint.22151]
vlog_severity = Level3
vhdl_severity = Level2
[nLint.22152]
vlog_severity = Level1
vhdl_severity = Level2
[nLint.22153]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22155]
vlog_severity = Level2
vlog_val = 
vhdl_severity = Level2
vhdl_val = 
[nLint.22157]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22159]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22161]
vlog_severity = Level2
vlog_val = CHECK_ALL
vhdl_severity = Level2
[nLint.22163]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22165]
vlog_severity = Level1
vlog_val = CHECK_ALL
vhdl_severity = Level2
vhdl_val = CHECK_ALL
[nLint.22167]
vlog_severity = Level1
vhdl_severity = Level1
[nLint.22168]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22169]
vlog_severity = Level3
vhdl_severity = Level3
[nLint.22175]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22176]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22177]
vlog_severity = Level3
vhdl_severity = Level2
[nLint.22179]
vlog_severity = Level3
vhdl_severity = Level3
[nLint.22181]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22187]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22193]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22194]
vlog_severity = Level2
vlog_val = 1000
vhdl_severity = Level2
[nLint.22195]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22199]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22201]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22203]
vlog_severity = Level2
vlog_val = BOTH
vhdl_severity = Level2
vhdl_val = BOTH
[nLint.22204]
vlog_severity = Level2
vlog_val = BOTH
vhdl_severity = Level2
vhdl_val = BOTH
[nLint.22205]
vlog_severity = Level2
vlog_val = BOTH
vhdl_severity = Level2
vhdl_val = BOTH
[nLint.22207]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22209]
vlog_severity = Level2
vlog_val = IGNORE_ADDR
vhdl_severity = Level2
vhdl_val = IGNORE_ADDR
[nLint.22210]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22211]
vlog_severity = Level1
vhdl_severity = Level3
[nLint.22213]
vlog_severity = Level1
vhdl_severity = Level3
[nLint.22217]
vlog_severity = Level3
vhdl_severity = Level2
[nLint.22218]
vlog_severity = Level3
vhdl_severity = Level2
[nLint.22219]
vlog_severity = Level3
vhdl_severity = Level2
[nLint.22220]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22221]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22223]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22225]
vlog_severity = Level3
vlog_val = TRUE
vhdl_severity = Level3
vhdl_val = TRUE
[nLint.22227]
vlog_severity = Level2
vlog_val = BOTH
vhdl_severity = Level2
vhdl_val = BOTH
[nLint.22228]
vlog_severity = Level2
vlog_val = BOTH
vhdl_severity = Level2
vhdl_val = BOTH
[nLint.22229]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22231]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22233]
vlog_severity = Level1
vhdl_severity = Level2
[nLint.22235]
vlog_severity = Level3
vhdl_severity = Level3
[nLint.22239]
vlog_severity = Level2
vlog_val = IGNORE_CONSTCASEEXPR
vhdl_severity = Level2
vhdl_val = IGNORE_CONSTCASEEXPR
[nLint.22243]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22246]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22247]
vlog_severity = Level2
vlog_val = IGNORE_DEPEND
vhdl_severity = Level2
[nLint.22249]
vlog_severity = Level3
vlog_val = VAR_GE_CON,ORIG_MUL_WIDTH
vhdl_severity = Level2
[nLint.22250]
vlog_severity = Level3
vhdl_severity = Level2
[nLint.22251]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22252]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22254]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22255]
vlog_severity = Level2
vlog_val = BOTH,CHECK_VOIDFUNC
vhdl_severity = Level2
vhdl_val = BOTH,CHECK_VOIDFUNC
[nLint.22259]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22261]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22263]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22265]
vlog_severity = Level3
vlog_val = VAR_GE_CON
vhdl_severity = Level2
[nLint.22267]
vlog_severity = Level2
vlog_val = IGNORE_INCRDECR
vhdl_severity = Level2
[nLint.22268]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.22269]
vlog_severity = Level2
vlog_val = SYNC,30
vhdl_severity = Level2
vhdl_val = SYNC,30
[nLint.22271]
vlog_severity = Level2
vlog_val = 10
vhdl_severity = Level2
vhdl_val = 10
[nLint.22273]
vlog_severity = Level3
vhdl_severity = Level3
[nLint.22275]
vlog_severity = Level3
vhdl_severity = Level3
[nLint.22277]
vlog_severity = Level3
vhdl_severity = Level3
[nLint.22279]
vlog_severity = Level2
vlog_val = "INPUT, OUTPUT, INOUT"
vhdl_severity = Level2
vhdl_val = "INPUT, OUTPUT, INOUT"
[nLint.22281]
vlog_severity = Level2
vlog_val = "INPUT, OUTPUT, INOUT"
vhdl_severity = Level2
[nLint.22283]
vlog_severity = Level2
vlog_val = "INPUT, OUTPUT, INOUT"
vhdl_severity = Level2
[nLint.22301]
vlog_severity = Level2
vlog_val = IGNORE_CONST_RHS,ORIG_MUL_WIDTH
vhdl_severity = Level2
[nLint.22303]
vlog_severity = Level3
vlog_val = LHS_GE_RHS,VAR_EQ_CON
vhdl_severity = Level2
[nLint.22306]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23001]
vlog_severity = Level2
vlog_val = IGNORE_IN_COMB
vhdl_severity = Level2
vhdl_val = IGNORE_IN_COMB
[nLint.23002]
vlog_severity = Level2
vlog_val = "REGISTER, LATCH, MEMORY, COUNTER"
vhdl_severity = Level2
vhdl_val = "REGISTER, LATCH, MEMORY, COUNTER"
[nLint.23003]
vlog_severity = Level2
vlog_val = FALSE
vhdl_severity = Level2
vhdl_val = FALSE
[nLint.23004]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23005]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23006]
vlog_severity = Level1
vhdl_severity = Level2
[nLint.23007]
vlog_severity = Level2
vlog_val = IGNORE_IN_SEQ,FOLLOW_FULL_CASE_DIRECTIVE
vhdl_severity = Level2
[nLint.23008]
vlog_severity = Level2
vlog_val = IGNORE_IN_SEQ
vhdl_severity = Level2
[nLint.23009]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23010]
vlog_severity = Level1
vhdl_severity = Level2
[nLint.23011]
vlog_severity = Level3
vhdl_severity = Level3
[nLint.23013]
vlog_severity = Level2
vlog_val = BOTH,IGNORE_PART_SEL
vhdl_severity = Level2
vhdl_val = BOTH,IGNORE_PART_SEL
[nLint.23015]
vlog_severity = Level3
vlog_val = BLOCKING,REG_INFER_ASSIGN
vhdl_severity = Level2
[nLint.23016]
vlog_severity = Level3
vlog_val = NONBLOCKING,FALSE
vhdl_severity = Level2
[nLint.23017]
vlog_severity = Level2
vlog_val = CHECK_BOTH
vhdl_severity = Level2
vhdl_val = CHECK_BOTH
[nLint.23021]
vlog_severity = Level2
vlog_val = NON_LEAF,""
vhdl_severity = Level2
[nLint.23025]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23026]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23027]
vlog_severity = Level2
vlog_val = IGNORE_SUBPROG
vhdl_severity = Level2
vhdl_val = IGNORE_SUBPROG
[nLint.23028]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23029]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23030]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23031]
vlog_severity = Level3
vlog_val = IGNORE_CASEEQ
vhdl_severity = Level3
vhdl_val = IGNORE_CASEEQ
[nLint.23033]
vlog_severity = Level2
vlog_val = CONSTANT
vhdl_severity = Level2
[nLint.23034]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23035]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23037]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23039]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23042]
vlog_severity = Level2
vlog_val = "CLOCK, RESET, SET, LATCH_ENABLE, TRI_ENABLE"
vhdl_severity = Level2
vhdl_val = "CLOCK, RESET, SET, LATCH_ENABLE, TRI_ENABLE"
[nLint.23043]
vlog_severity = Level2
vlog_val = "CLOCK, RESET, SET, LATCH_ENABLE, TRI_ENABLE"
vhdl_severity = Level2
vhdl_val = "CLOCK, RESET, SET, LATCH_ENABLE, TRI_ENABLE"
[nLint.23044]
vlog_severity = Level2
vlog_val = "LATCH_ENABLE, TRI_ENABLE"
vhdl_severity = Level2
vhdl_val = "LATCH_ENABLE, TRI_ENABLE"
[nLint.23045]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23047]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23049]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23050]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23051]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23053]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23055]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23057]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23059]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23061]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23065]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23069]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23071]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23073]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23075]
vlog_severity = Level1
vhdl_severity = Level2
[nLint.23077]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23079]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23083]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23087]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23089]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23091]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23095]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23097]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23099]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23101]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23103]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23105]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23107]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23109]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23115]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23117]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23119]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23121]
vlog_severity = Level3
vlog_val = BOTH
vhdl_severity = Level3
vhdl_val = BOTH
[nLint.23122]
vlog_severity = Level3
vlog_val = IGNORE_NOTFULL
vhdl_severity = Level3
vhdl_val = IGNORE_NOTFULL
[nLint.23123]
vlog_severity = Level2
vlog_val = BOTH,IGNORE_MULTI_CHOICE
vhdl_severity = Level2
vhdl_val = BOTH,IGNORE_MULTI_CHOICE
[nLint.23125]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23127]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23129]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23131]
vlog_severity = Level2
vlog_val = IGNORE_DEFAULT
vhdl_severity = Level2
[nLint.23133]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23135]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23137]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23401]
vlog_severity = Level1
vhdl_severity = Level2
[nLint.23405]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23407]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.23409]
vlog_severity = Level1
vhdl_severity = Level2
[nLint.24001]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.24003]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.24005]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.24007]
vlog_severity = Level2
vlog_val = CHECK_ALL
vhdl_severity = Level2
[nLint.24009]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.24011]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.24013]
vlog_severity = Level2
vlog_val = "IFDEF, IFNDEF"
vhdl_severity = Level2
[nLint.24015]
vlog_severity = Level2
vlog_val = "synopsys,translate_off,translate_on,parallel_case,full_case,state_vector,enum,template,dc_script_begin, dc_script_end,map_to_module,return_port_name,sync_set_reset,async_set_reset,async_set_reset_local,sync_set_reset_local, async_set_reset_local_all,sync_\
set_reset_local_all,one_hot,one_cold"
vhdl_severity = Level2
vhdl_val = "synopsys,translate_off,translate_on,parallel_case,full_case,state_vector,enum,template,dc_script_begin, dc_script_end,map_to_module,return_port_name,sync_set_reset,async_set_reset,async_set_reset_local,sync_set_reset_local, async_set_reset_local_all,sync_\
set_reset_local_all,one_hot,one_cold"
[nLint.24017]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.24019]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.24021]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.25001]
vlog_severity = Level3
vlog_val = "CHECK_PART_SEL, IGNORE_INITIALVALUE, CHECK_TOP_SIGNAL"
vhdl_severity = Level3
vhdl_val = "CHECK_PART_SEL, IGNORE_INITIALVALUE, CHECK_TOP_SIGNAL"
[nLint.25003]
vlog_severity = Level2
vlog_val = "CHECK_TOP_SIGNAL, CHECK_THROUGH_HIERARCHY"
vhdl_severity = Level2
vhdl_val = "CHECK_TOP_SIGNAL, CHECK_THROUGH_HIERARCHY"
[nLint.25005]
vlog_severity = Level3
vlog_val = BOTH
vhdl_severity = Level2
[nLint.25007]
vlog_severity = Level3
vlog_val = ""
vhdl_severity = Level2
[nLint.25009]
vlog_severity = Level2
vlog_val = 10,"CLOCK, RESET, SET, LATCH_ENABLE, TRI_ENABLE, SCAN_ENABLE"
vhdl_severity = Level2
vhdl_val = 10,"CLOCK, RESET, SET, LATCH_ENABLE, TRI_ENABLE, SCAN_ENABLE"
[nLint.25011]
vlog_severity = Level2
vlog_val = 10
vhdl_severity = Level2
vhdl_val = 10
[nLint.25013]
vlog_severity = Level2
vlog_val = 10
vhdl_severity = Level2
vhdl_val = 10
[nLint.25014]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.25015]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.25016]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.25017]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.25019]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.25021]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.26001]
vlog_severity = Level2
vlog_val = 1024
vhdl_severity = Level2
[nLint.26003]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.26005]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.26007]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.26009]
vlog_severity = Level3
vhdl_severity = Level2
[nLint.26011]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.26013]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.26015]
vlog_severity = Level2
vlog_val = 8096
vhdl_severity = Level2
[nLint.27001]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27003]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27007]
vlog_severity = Level2
vhdl_severity = Level2
vhdl_val = CASE_LOWER
[nLint.27015]
vlog_severity = Level2
vlog_val = v
vhdl_severity = Level2
vhdl_val = vhd
[nLint.27027]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27028]
vlog_severity = Level2
vlog_val = 
vhdl_severity = Level2
vhdl_val = 
[nLint.27029]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27031]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27033]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27035]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27037]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27039]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27041]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27043]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27044]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27045]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27047]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27049]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27051]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27055]
vlog_severity = Level2
vlog_val = 1000
vhdl_severity = Level2
vhdl_val = 1000
[nLint.27063]
vlog_severity = Level2
vhdl_severity = Level2
vhdl_val = CASE_UPPER
[nLint.27069]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27071]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27077]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27081]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27083]
vlog_severity = Level2
vhdl_severity = Level2
vhdl_val = RESOLVED
[nLint.27085]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27093]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27095]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27099]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27101]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27105]
vlog_severity = Level2
vhdl_severity = Level2
vhdl_val = "DELAYED,STABLE,QUIET,TRANSACTION"
[nLint.27107]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27109]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27111]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27115]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27119]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27122]
vlog_severity = Level2
vlog_val = IGNORE_IN_SEQ
vhdl_severity = Level2
[nLint.27123]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27124]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27125]
vlog_severity = Level2
vlog_val = CHECK_REF_ONLY
vhdl_severity = Level2
vhdl_val = CHECK_REF_ONLY
[nLint.27126]
vlog_severity = Level2
vlog_val = CHECK_REF_ONLY
vhdl_severity = Level2
vhdl_val = CHECK_REF_ONLY
[nLint.27127]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27128]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27130]
vlog_severity = Level2
vlog_val = NONBLOCKING,CHECK_INITASS
vhdl_severity = Level2
[nLint.27131]
vlog_severity = Level2
vlog_val = NONBLOCKING
vhdl_severity = Level2
[nLint.27143]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27144]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27155]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27159]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27163]
vlog_severity = Level2
vhdl_severity = Level2
vhdl_val = 
[nLint.27181]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27201]
vlog_severity = Level2
vhdl_severity = Level2
vhdl_val = 3,16
[nLint.27203]
vlog_severity = Level2
vhdl_severity = Level2
vhdl_val = CASE_LOWER
[nLint.27205]
vlog_severity = Level2
vhdl_severity = Level2
vhdl_val = SUFFIX,_ety
[nLint.27209]
vlog_severity = Level2
vlog_val = 3,16
vhdl_severity = Level2
vhdl_val = 3,16
[nLint.27211]
vlog_severity = Level2
vlog_val = CASE_LOWER
vhdl_severity = Level2
vhdl_val = CASE_LOWER
[nLint.27213]
vlog_severity = Level2
vlog_val = SUFFIX,_module
vhdl_severity = Level2
vhdl_val = SUFFIX,_arch
[nLint.27217]
vlog_severity = Level2
vhdl_severity = Level2
vhdl_val = 3,16
[nLint.27219]
vlog_severity = Level2
vhdl_severity = Level2
vhdl_val = CASE_LOWER
[nLint.27221]
vlog_severity = Level2
vhdl_severity = Level2
vhdl_val = SUFFIX,_pkg
[nLint.27225]
vlog_severity = Level2
vhdl_severity = Level2
vhdl_val = 3,16
[nLint.27227]
vlog_severity = Level2
vhdl_severity = Level2
vhdl_val = CASE_LOWER
[nLint.27229]
vlog_severity = Level2
vhdl_severity = Level2
vhdl_val = SUFFIX,_cfg
[nLint.27233]
vlog_severity = Level2
vlog_val = 3,16
vhdl_severity = Level2
vhdl_val = 3,16
[nLint.27235]
vlog_severity = Level2
vlog_val = CASE_LOWER
vhdl_severity = Level2
vhdl_val = CASE_LOWER
[nLint.27241]
vlog_severity = Level2
vhdl_severity = Level2
vhdl_val = 3,16
[nLint.27245]
vlog_severity = Level2
vhdl_severity = Level2
vhdl_val = PREFIX,com_
[nLint.27249]
vlog_severity = Level2
vlog_val = 3,16
vhdl_severity = Level2
vhdl_val = 3,16
[nLint.27251]
vlog_severity = Level2
vlog_val = CASE_LOWER
vhdl_severity = Level2
vhdl_val = CASE_LOWER
[nLint.27257]
vlog_severity = Level2
vhdl_severity = Level2
vhdl_val = 3,16
[nLint.27259]
vlog_severity = Level2
vhdl_severity = Level2
vhdl_val = CASE_LOWER
[nLint.27261]
vlog_severity = Level2
vhdl_severity = Level2
vhdl_val = PREFIX,c_
[nLint.27265]
vlog_severity = Level2
vlog_val = 3,16
vhdl_severity = Level2
vhdl_val = 3,16
[nLint.27267]
vlog_severity = Level2
vlog_val = CASE_LOWER
vhdl_severity = Level2
vhdl_val = CASE_LOWER
[nLint.27269]
vlog_severity = Level2
vlog_val = SUFFIX,_typ
vhdl_severity = Level2
vhdl_val = SUFFIX,_typ
[nLint.27273]
vlog_severity = Level2
vlog_val = 3,16
vhdl_severity = Level2
vhdl_val = 3,16
[nLint.27277]
vlog_severity = Level2
vlog_val = PREFIX,p_
vhdl_severity = Level2
vhdl_val = PREFIX,g_
[nLint.27285]
vlog_severity = Level2
vlog_val = PREFIX,s_
vhdl_severity = Level2
vhdl_val = PREFIX,s_
[nLint.27287]
vlog_severity = Level2
vlog_val = var_.*
vhdl_severity = Level2
[nLint.27288]
vlog_severity = Level2
vlog_val = 3,16
vhdl_severity = Level2
[nLint.27289]
vlog_severity = Level2
vlog_val = .*_fld
vhdl_severity = Level2
[nLint.27290]
vlog_severity = Level2
vlog_val = 3,16
vhdl_severity = Level2
[nLint.27293]
vlog_severity = Level2
vlog_val = PREFIX,v_
vhdl_severity = Level2
vhdl_val = PREFIX,v_
[nLint.27297]
vlog_severity = Level2
vlog_val = 3,16
vhdl_severity = Level2
vhdl_val = 3,16
[nLint.27299]
vlog_severity = Level2
vlog_val = CASE_LOWER
vhdl_severity = Level2
vhdl_val = CASE_LOWER
[nLint.27301]
vlog_severity = Level2
vlog_val = PREFIX,f_
vhdl_severity = Level2
vhdl_val = PREFIX,f_
[nLint.27305]
vlog_severity = Level2
vlog_val = 3,16
vhdl_severity = Level2
vhdl_val = 3,16
[nLint.27307]
vlog_severity = Level2
vlog_val = CASE_LOWER
vhdl_severity = Level2
vhdl_val = CASE_LOWER
[nLint.27309]
vlog_severity = Level2
vlog_val = PREFIX,p_
vhdl_severity = Level2
vhdl_val = PREFIX,p_
[nLint.27313]
vlog_severity = Level2
vhdl_severity = Level2
vhdl_val = 3,16
[nLint.27315]
vlog_severity = Level2
vhdl_severity = Level2
vhdl_val = CASE_LOWER
[nLint.27317]
vlog_severity = Level2
vhdl_severity = Level2
vhdl_val = PREFIX,blk_
[nLint.27321]
vlog_severity = Level2
vhdl_severity = Level2
vhdl_val = 3,16
[nLint.27325]
vlog_severity = Level2
vhdl_severity = Level2
vhdl_val = PREFIX,attr_
[nLint.27327]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27328]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27329]
vlog_severity = Level2
vlog_val = NET_DECL
vhdl_severity = Level2
[nLint.27331]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27333]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27335]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27337]
vlog_severity = Level2
vlog_val = CHECK_FULL_CASE
vhdl_severity = Level2
[nLint.27338]
vlog_severity = Level2
vlog_val = IGNORE_SIGNED_POSITIVE_CONST
vhdl_severity = Level2
[nLint.27339]
vlog_severity = Level2
vlog_val = CHECK_ALL
vhdl_severity = Level2
[nLint.27341]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27343]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27345]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27347]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27349]
vlog_severity = Level2
vlog_val = END
vhdl_severity = Level2
[nLint.27351]
vlog_severity = Level2
vlog_val = "UNARY_PLUS, UNARY_MINUS, MULTIPLY, DIVIDE, MOD, POWER"
vhdl_severity = Level2
vhdl_val = "UNARY_PLUS, UNARY_MINUS, MULTIPLY, DIVIDE, MOD, POWER"
[nLint.27353]
vlog_severity = Level2
vlog_val = 
vhdl_severity = Level2
[nLint.27355]
vlog_severity = Level2
vlog_val = INPUT_SIGNAL_TO_OUTPUT_PORT
vhdl_severity = Level2
[nLint.27356]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27357]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27359]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27361]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27363]
vlog_severity = Level2
vlog_val = IGNORE_GENERATEFOR
vhdl_severity = Level2
[nLint.27365]
vlog_severity = Level2
vlog_val = CASEX
vhdl_severity = Level2
[nLint.27367]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27369]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27371]
vlog_severity = Level2
vlog_val = "parallel_case,full_case"
vhdl_severity = Level2
vhdl_val = "parallel_case,full_case"
[nLint.27373]
vlog_severity = Level2
vlog_val = SUFFIX,_ns
vhdl_severity = Level2
vhdl_val = SUFFIX,_ns
[nLint.27375]
vlog_severity = Level2
vlog_val = .*
vhdl_severity = Level2
vhdl_val = .*
[nLint.27377]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27379]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27381]
vlog_severity = Level2
vlog_val = IGNORE_TIE_LOW_HIGH
vhdl_severity = Level2
vhdl_val = IGNORE_TIE_LOW_HIGH
[nLint.27383]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27385]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27387]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27389]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27391]
vlog_severity = Level2
vlog_val = logic
vhdl_severity = Level2
[nLint.27393]
vlog_severity = Level2
vlog_val = logic
vhdl_severity = Level2
[nLint.27394]
vlog_severity = Level2
vlog_val = logic
vhdl_severity = Level2
[nLint.27395]
vlog_severity = Level2
vlog_val = "my_bit,bit,logic;"
vhdl_severity = Level2
[nLint.27397]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27399]
vlog_severity = Level2
vlog_val = //sync
vhdl_severity = Level2
vhdl_val = --sync
[nLint.27401]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27411]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27412]
vlog_severity = Level2
vlog_val = 40
vhdl_severity = Level2
[nLint.27413]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27415]
vlog_severity = Level2
vlog_val = D1
vhdl_severity = Level2
[nLint.27417]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27419]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27421]
vlog_severity = Level3
vlog_val = CHECK_ALL
vhdl_severity = Level2
[nLint.27423]
vlog_severity = Level3
vlog_val = IGNORE_DEFAULT
vhdl_severity = Level2
[nLint.27425]
vlog_severity = Level3
vhdl_severity = Level2
[nLint.27427]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27505]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27507]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27509]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27515]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27517]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27518]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27519]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27521]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27522]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27523]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27524]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27525]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27529]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27531]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27533]
vlog_severity = Level2
vhdl_severity = Level3
[nLint.27535]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27536]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27537]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27539]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27541]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27543]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27545]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27549]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27550]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27551]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27553]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27557]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27559]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27561]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27563]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27565]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27567]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27571]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27573]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27575]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27577]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27581]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27585]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27587]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27589]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27595]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27597]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27598]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27599]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27601]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27605]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27609]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27610]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27613]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27615]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27617]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27619]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27621]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27623]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27625]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27627]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27629]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27631]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27633]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27635]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27639]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27641]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27643]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27645]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27649]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27651]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27653]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27655]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27657]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27661]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27662]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27663]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27664]
vlog_severity = Level2
vlog_val = 16
vhdl_severity = Level2
[nLint.27665]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27667]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27668]
vlog_severity = Level2
vlog_val = 8
vhdl_severity = Level2
[nLint.27669]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27670]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27671]
vlog_severity = Level3
vlog_val = 3
vhdl_severity = Level2
[nLint.27672]
vlog_severity = Level2
vlog_val = 32
vhdl_severity = Level2
[nLint.27673]
vlog_severity = Level2
vlog_val = IGNORE_TEMPVAR
vhdl_severity = Level2
[nLint.27674]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27675]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27676]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27801]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27803]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27805]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27807]
vlog_severity = Level2
vlog_val = IGNORE_NOT_FULL_RET
vhdl_severity = Level2
[nLint.27813]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27815]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27817]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27819]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27821]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27823]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27825]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.27827]
vlog_severity = Level2
vlog_val = ALL
vhdl_severity = Level2
[nLint.27829]
vlog_severity = Level2
vlog_val = "CHECK_ALWAYS_LATCH, CHECK_ALWAYS_FF, CHECK_ALWAYS_COMB"
vhdl_severity = Level2
[nLint.28009]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.28011]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.28015]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.29001]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.29002]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.29003]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.29004]
vlog_severity = Level2
vlog_val = .*GTECH.*
vhdl_severity = Level2
vhdl_val = .*GTECH.*
[nLint.29005]
vlog_severity = Level2
vlog_val = 3
vhdl_severity = Level2
vhdl_val = 3
[nLint.29006]
vlog_severity = Level2
vlog_val = 2
vhdl_severity = Level2
vhdl_val = 2
[nLint.29100]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.29101]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.29102]
vlog_severity = Level2
vlog_val = "always, assign, function, task"
vhdl_severity = Level2
vhdl_val = "always, assign, function, task"
[nLint.29103]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.29104]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.29105]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.29106]
vlog_severity = Level2
vlog_val = file_header.tmpl
vhdl_severity = Level2
vhdl_val = file_header.tmpl
[nLint.29107]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.29108]
vlog_severity = Level2
vlog_val = "always, assign, function, initial, specify, task"
vhdl_severity = Level2
vhdl_val = "always, assign, function, initial, specify, task"
[nLint.29109]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.29110]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.29111]
vlog_severity = Level2
vlog_val = construct_header.tmpl
vhdl_severity = Level2
vhdl_val = construct_header.tmpl
[nLint.29112]
vlog_severity = Level2
vlog_val = "BitNegOp, EqOp, NotEqOp"
vhdl_severity = Level2
vhdl_val = "BitNegOp, EqOp, NotEqOp"
[nLint.29113]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.29114]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.29115]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.29116]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.29118]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.29201]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.29204]
vlog_severity = Level1
vhdl_severity = Level2
[nLint.29206]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.29211]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.29212]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.29801]
vlog_severity = Level3
vhdl_severity = Level2
[nLint.29802]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.29803]
vlog_severity = Level3
vhdl_severity = Level2
[nLint.29804]
vlog_severity = Level2
vlog_val = 200
vhdl_severity = Level2
vhdl_val = 200
[nLint.29805]
vlog_severity = Level3
vhdl_severity = Level2
[nLint.29806]
vlog_severity = Level3
vhdl_severity = Level2
[nLint.29807]
vlog_severity = Level3
vhdl_severity = Level2
[nLint.29808]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.29809]
vlog_severity = Level3
vhdl_severity = Level2
[nLint.29810]
vlog_severity = Level3
vhdl_severity = Level2
[nLint.29811]
vlog_severity = Level3
vhdl_severity = Level2
[nLint.29812]
vlog_severity = Level3
vhdl_severity = Level2
[nLint.29813]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.29814]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.29815]
vlog_severity = Level2
vlog_val = CHECK_CONDEXPR
vhdl_severity = Level2
vhdl_val = CHECK_CONDEXPR
[nLint.29816]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.29817]
vlog_severity = Level3
vhdl_severity = Level2
[nLint.29818]
vlog_severity = Level3
vhdl_severity = Level2
[nLint.29819]
vlog_severity = Level3
vhdl_severity = Level2
[nLint.29820]
vlog_severity = Level3
vhdl_severity = Level2
[nLint.29821]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.29822]
vlog_severity = Level2
vhdl_severity = Level2
[nLint.29823]
vlog_severity = Level3
vlog_TranslateOff = ON
vhdl_severity = Level2
[nLint.Block Interconnect]
27355 = Enable NONE TRUE NONE
27356 = Enable NONE TRUE NONE
[nLint.CTS]
25019 = Disable NONE TRUE NONE
25021 = Disable NONE TRUE NONE
[nLint.Clock]
22051 = Enable NONE TRUE NONE
22052 = Enable NONE TRUE NONE
22130 = Enable Enable TRUE TRUE
22133 = Enable NONE TRUE NONE
27419 = Enable Disable TRUE TRUE
28009 = Enable Disable TRUE TRUE
28011 = Enable Disable TRUE TRUE
28015 = Enable Disable TRUE TRUE
[nLint.Coding Style]
21023 = Disable Enable TRUE TRUE
21043 = Enable Disable TRUE TRUE
21044 = Enable Disable TRUE TRUE
22021 = Enable Disable TRUE TRUE
22023 = Enable Disable TRUE TRUE
22025 = Disable Disable TRUE TRUE
22027 = Enable Disable TRUE TRUE
22029 = Disable Disable TRUE TRUE
22031 = Disable Disable TRUE TRUE
22032 = Disable Disable TRUE TRUE
22033 = Enable Disable TRUE TRUE
22035 = Disable Disable TRUE TRUE
22038 = Disable Disable TRUE TRUE
22039 = Enable Disable TRUE TRUE
22041 = Disable NONE TRUE NONE
22043 = Enable Enable TRUE TRUE
22044 = Enable Disable TRUE TRUE
22049 = Disable Disable TRUE TRUE
22107 = Enable NONE TRUE NONE
22108 = Enable NONE TRUE NONE
22161 = Enable NONE TRUE NONE
22163 = Enable NONE TRUE NONE
22246 = Disable NONE TRUE NONE
22306 = Enable NONE TRUE NONE
23009 = Enable NONE TRUE NONE
24009 = Enable Disable TRUE TRUE
27001 = NONE Disable NONE TRUE
27027 = NONE Disable NONE TRUE
27028 = Enable Disable TRUE TRUE
27029 = NONE Disable NONE TRUE
27031 = NONE Disable NONE TRUE
27033 = NONE Disable NONE TRUE
27035 = NONE Disable NONE TRUE
27037 = NONE Disable NONE TRUE
27039 = NONE Disable NONE TRUE
27041 = NONE Disable NONE TRUE
27043 = NONE Disable NONE TRUE
27044 = NONE Disable NONE TRUE
27045 = NONE Disable NONE TRUE
27047 = NONE Disable NONE TRUE
27049 = NONE Disable NONE TRUE
27051 = NONE Disable NONE TRUE
27055 = Disable Disable TRUE TRUE
27069 = NONE Disable NONE TRUE
27071 = NONE Disable NONE TRUE
27077 = NONE Disable NONE TRUE
27081 = NONE Disable NONE TRUE
27083 = NONE Disable NONE TRUE
27085 = NONE Disable NONE TRUE
27093 = NONE Disable NONE TRUE
27095 = NONE Disable NONE TRUE
27099 = NONE Disable NONE TRUE
27101 = NONE Disable NONE TRUE
27105 = NONE Disable NONE TRUE
27107 = NONE Disable NONE TRUE
27109 = NONE Disable NONE TRUE
27111 = NONE Disable NONE TRUE
27115 = NONE Disable NONE TRUE
27119 = NONE Disable NONE TRUE
27124 = NONE Disable NONE TRUE
27130 = Enable NONE TRUE NONE
27131 = Enable NONE TRUE NONE
27143 = NONE Disable NONE TRUE
27144 = NONE Disable NONE TRUE
27338 = Enable NONE TRUE NONE
27339 = Enable NONE TRUE NONE
27347 = Enable Disable TRUE TRUE
27349 = Disable NONE TRUE NONE
27351 = Disable Disable TRUE TRUE
27353 = Disable NONE TRUE NONE
27357 = Enable NONE TRUE NONE
27363 = Disable NONE TRUE NONE
27365 = Disable NONE TRUE NONE
27367 = Disable NONE TRUE NONE
27371 = Disable Disable TRUE TRUE
27377 = Enable Enable TRUE TRUE
27379 = Enable NONE TRUE NONE
27389 = Disable NONE TRUE NONE
27391 = Enable NONE TRUE NONE
27393 = Disable NONE TRUE NONE
27394 = Enable NONE TRUE NONE
27395 = Disable NONE TRUE NONE
27397 = Disable NONE TRUE NONE
27399 = Disable Disable TRUE TRUE
27411 = Enable NONE TRUE NONE
27412 = Disable NONE TRUE NONE
27675 = Disable NONE TRUE NONE
27807 = Enable NONE TRUE NONE
27815 = Enable NONE TRUE NONE
27817 = Enable NONE TRUE NONE
27819 = Enable NONE TRUE NONE
29003 = Enable NONE TRUE NONE
29005 = Disable NONE TRUE NONE
29006 = Disable NONE TRUE NONE
29100 = Enable NONE TRUE NONE
29103 = Disable NONE TRUE NONE
29801 = Enable NONE TRUE NONE
29804 = Disable NONE TRUE NONE
29811 = Disable NONE TRUE NONE
29812 = Enable NONE TRUE NONE
[nLint.DFT]
22001 = Enable Enable TRUE TRUE
22002 = Enable Disable TRUE TRUE
22007 = Disable Disable TRUE TRUE
22008 = Enable NONE TRUE NONE
22011 = Enable Enable TRUE TRUE
22013 = Disable Disable TRUE TRUE
22014 = Disable Disable TRUE TRUE
22020 = Enable Disable TRUE TRUE
22053 = Enable Enable TRUE TRUE
22054 = Enable Disable TRUE TRUE
22055 = Enable Disable TRUE TRUE
22056 = Enable Disable TRUE TRUE
22057 = Enable Disable TRUE TRUE
22058 = Enable Disable TRUE TRUE
22059 = Enable Disable TRUE TRUE
22127 = Enable Enable TRUE TRUE
22128 = Disable Disable TRUE TRUE
22129 = Enable Enable TRUE TRUE
22130 = Enable Enable TRUE TRUE
22131 = Enable Disable TRUE TRUE
22132 = Enable Disable TRUE TRUE
22134 = Enable NONE TRUE NONE
22181 = Disable Disable TRUE TRUE
22203 = Enable Disable TRUE TRUE
22204 = Enable Disable TRUE TRUE
22205 = Enable Disable TRUE TRUE
22227 = Enable Disable TRUE TRUE
22228 = Enable Disable TRUE TRUE
22229 = Enable Enable TRUE TRUE
22231 = Enable Enable TRUE TRUE
22269 = Enable Disable TRUE TRUE
22271 = Enable Disable TRUE TRUE
25001 = Enable Enable TRUE TRUE
25003 = Enable Enable TRUE TRUE
25014 = Enable NONE TRUE NONE
27381 = Enable Disable TRUE TRUE
27383 = Enable Disable TRUE TRUE
27385 = Enable Disable TRUE TRUE
27387 = Enable Disable TRUE TRUE
[nLint.Design Style]
22001 = Enable Enable TRUE TRUE
22002 = Enable Disable TRUE TRUE
22007 = Disable Disable TRUE TRUE
22008 = Enable NONE TRUE NONE
22010 = Enable Disable TRUE TRUE
22011 = Enable Enable TRUE TRUE
22013 = Disable Disable TRUE TRUE
22014 = Disable Disable TRUE TRUE
22017 = Enable Enable TRUE TRUE
22045 = Disable NONE TRUE NONE
22053 = Enable Enable TRUE TRUE
22054 = Enable Disable TRUE TRUE
22055 = Enable Disable TRUE TRUE
22056 = Enable Disable TRUE TRUE
22057 = Enable Disable TRUE TRUE
22058 = Enable Disable TRUE TRUE
22059 = Enable Disable TRUE TRUE
22061 = Enable Disable TRUE TRUE
22063 = Enable Enable TRUE TRUE
22067 = Disable Disable TRUE TRUE
22097 = Disable NONE TRUE NONE
22105 = Enable Disable TRUE TRUE
22117 = Enable Enable TRUE TRUE
22118 = Enable NONE TRUE NONE
22120 = Enable NONE TRUE NONE
22122 = Enable NONE TRUE NONE
22123 = Disable NONE TRUE NONE
22124 = Disable NONE TRUE NONE
22126 = Disable NONE TRUE NONE
22131 = Enable Disable TRUE TRUE
22149 = Enable Disable TRUE TRUE
22152 = Disable NONE TRUE NONE
22153 = Enable NONE TRUE NONE
22159 = Enable Disable TRUE TRUE
22167 = Enable Disable TRUE TRUE
22168 = Enable NONE TRUE NONE
22175 = Enable Disable TRUE TRUE
22176 = Enable Disable TRUE TRUE
22181 = Disable Disable TRUE TRUE
22201 = Disable Disable TRUE TRUE
22203 = Enable Disable TRUE TRUE
22204 = Enable Disable TRUE TRUE
22205 = Enable Disable TRUE TRUE
22221 = Enable Disable TRUE TRUE
22223 = Enable Disable TRUE TRUE
22225 = Enable Enable TRUE TRUE
22227 = Enable Disable TRUE TRUE
22228 = Enable Disable TRUE TRUE
22229 = Enable Enable TRUE TRUE
22231 = Enable Enable TRUE TRUE
22233 = Enable Disable TRUE TRUE
22252 = Disable NONE TRUE NONE
22254 = Enable NONE TRUE NONE
22261 = Disable Disable TRUE TRUE
22263 = Enable NONE TRUE NONE
22269 = Enable Disable TRUE TRUE
22271 = Enable Disable TRUE TRUE
22273 = Enable Disable TRUE TRUE
22275 = Enable Disable TRUE TRUE
22277 = Enable Disable TRUE TRUE
23001 = Disable Disable TRUE TRUE
23035 = Enable NONE TRUE NONE
23037 = Enable NONE TRUE NONE
23042 = Enable Disable TRUE TRUE
23043 = Enable Disable TRUE TRUE
23044 = Enable Disable TRUE TRUE
23121 = Disable Disable TRUE TRUE
23122 = Enable Disable TRUE TRUE
25001 = Enable Enable TRUE TRUE
25003 = Enable Enable TRUE TRUE
25005 = Disable NONE TRUE NONE
25007 = Enable NONE TRUE NONE
25009 = Enable Enable TRUE TRUE
25011 = Disable Disable TRUE TRUE
25013 = Disable Disable TRUE TRUE
25015 = Disable Disable TRUE TRUE
25016 = Disable Disable TRUE TRUE
25017 = Enable NONE TRUE NONE
27327 = NONE Disable NONE TRUE
27328 = Disable NONE TRUE NONE
27329 = Enable NONE TRUE NONE
27331 = NONE Disable NONE TRUE
27341 = NONE Disable NONE TRUE
27343 = Enable NONE TRUE NONE
27359 = Disable NONE TRUE NONE
27361 = Enable Disable TRUE TRUE
27369 = Disable Disable TRUE TRUE
27401 = Disable Disable TRUE TRUE
27413 = Disable Disable TRUE TRUE
27417 = Disable Disable TRUE TRUE
27421 = Disable NONE TRUE NONE
27423 = Enable NONE TRUE NONE
27425 = Enable NONE TRUE NONE
27427 = Disable NONE TRUE NONE
27827 = Enable NONE TRUE NONE
29108 = Disable NONE TRUE NONE
29114 = Enable NONE TRUE NONE
29802 = Disable NONE TRUE NONE
29803 = Disable NONE TRUE NONE
29808 = Enable NONE TRUE NONE
29809 = Enable NONE TRUE NONE
29813 = Enable NONE TRUE NONE
29814 = Disable NONE TRUE NONE
29815 = Disable NONE TRUE NONE
29816 = Disable NONE TRUE NONE
29817 = Disable NONE TRUE NONE
[nLint.ERC]
23401 = Enable NONE TRUE NONE
23405 = Enable NONE TRUE NONE
23407 = Enable NONE TRUE NONE
23409 = Enable NONE TRUE NONE
[nLint.HDL Translation]
24001 = Disable NONE TRUE NONE
24003 = NONE Disable NONE TRUE
24005 = Enable NONE TRUE NONE
24007 = Enable NONE TRUE NONE
24011 = Disable NONE TRUE NONE
24013 = Disable NONE TRUE NONE
27143 = NONE Disable NONE TRUE
27144 = NONE Disable NONE TRUE
[nLint.Language Construct]
22003 = Enable Enable TRUE TRUE
22004 = Enable Enable TRUE TRUE
22005 = Enable Enable TRUE TRUE
22006 = Disable NONE TRUE NONE
22009 = Enable NONE TRUE NONE
22012 = Enable Enable TRUE TRUE
22015 = Enable NONE TRUE NONE
22018 = Disable NONE TRUE NONE
22019 = Enable NONE TRUE NONE
22022 = Enable NONE TRUE NONE
22024 = Disable NONE TRUE NONE
22026 = Disable NONE TRUE NONE
22083 = Disable Disable TRUE TRUE
22084 = Enable NONE TRUE NONE
22085 = Enable Enable TRUE TRUE
22089 = Enable NONE TRUE NONE
22091 = Enable NONE TRUE NONE
22098 = Enable NONE TRUE NONE
22101 = Disable NONE TRUE NONE
22103 = Enable NONE TRUE NONE
22104 = Enable Disable TRUE TRUE
22106 = Enable NONE TRUE NONE
22109 = Disable NONE TRUE NONE
22119 = Enable NONE TRUE NONE
22121 = Enable NONE TRUE NONE
22125 = Enable NONE TRUE NONE
22139 = Enable NONE TRUE NONE
22151 = Enable NONE TRUE NONE
22155 = Enable Enable TRUE TRUE
22157 = Enable Enable TRUE TRUE
22165 = Enable Enable TRUE TRUE
22169 = Enable Enable TRUE TRUE
22187 = Enable NONE TRUE NONE
22199 = Enable NONE TRUE NONE
22209 = Enable Enable TRUE TRUE
22210 = Disable NONE TRUE NONE
22219 = Enable NONE TRUE NONE
22220 = Enable NONE TRUE NONE
22243 = Enable NONE TRUE NONE
22249 = Enable NONE TRUE NONE
22250 = Enable NONE TRUE NONE
22251 = Enable NONE TRUE NONE
22255 = Enable Enable TRUE TRUE
22259 = Enable NONE TRUE NONE
22265 = Enable NONE TRUE NONE
22267 = Disable NONE TRUE NONE
22268 = Disable NONE TRUE NONE
22301 = Disable NONE TRUE NONE
22303 = Disable NONE TRUE NONE
23006 = Disable NONE TRUE NONE
23007 = Enable NONE TRUE NONE
23010 = Enable NONE TRUE NONE
23028 = Disable NONE TRUE NONE
23029 = Enable Disable TRUE TRUE
23030 = Enable Disable TRUE TRUE
23031 = Enable Enable TRUE TRUE
24011 = Disable NONE TRUE NONE
24013 = Disable NONE TRUE NONE
24015 = Enable Disable TRUE TRUE
24019 = Enable Disable TRUE TRUE
24021 = Disable NONE TRUE NONE
26001 = Disable NONE TRUE NONE
26003 = Enable NONE TRUE NONE
26005 = Enable NONE TRUE NONE
26007 = Enable NONE TRUE NONE
26009 = Enable NONE TRUE NONE
26011 = Enable NONE TRUE NONE
26013 = Enable NONE TRUE NONE
26015 = Disable NONE TRUE NONE
27333 = Enable NONE TRUE NONE
27345 = Disable NONE TRUE NONE
27665 = Enable NONE TRUE NONE
29805 = Enable NONE TRUE NONE
29806 = Disable NONE TRUE NONE
29807 = Disable NONE TRUE NONE
[nLint.Naming Convention]
21001 = Disable Disable TRUE TRUE
21003 = Disable Disable TRUE TRUE
21005 = Disable Disable TRUE TRUE
21007 = Disable Disable TRUE TRUE
21009 = Disable Disable TRUE TRUE
21011 = Disable Disable TRUE TRUE
21013 = Disable Disable TRUE TRUE
21014 = Disable Disable TRUE TRUE
21015 = Disable Disable TRUE TRUE
21017 = Disable Disable TRUE TRUE
21019 = Disable Disable TRUE TRUE
21020 = Disable Disable TRUE TRUE
21021 = Disable Disable TRUE TRUE
21022 = Disable Disable TRUE TRUE
21025 = Disable NONE TRUE NONE
21027 = Disable Disable TRUE TRUE
21029 = Disable Disable TRUE TRUE
21031 = Disable Disable TRUE TRUE
21035 = Disable Disable TRUE TRUE
21041 = Disable Disable TRUE TRUE
21045 = Disable Disable TRUE TRUE
21047 = Disable NONE TRUE NONE
21049 = Disable Disable TRUE TRUE
21050 = Disable Disable TRUE TRUE
21051 = Disable Disable TRUE TRUE
21052 = Disable NONE TRUE NONE
21053 = Disable NONE TRUE NONE
21055 = Disable NONE TRUE NONE
21057 = Disable Disable TRUE TRUE
24007 = Enable NONE TRUE NONE
27007 = NONE Disable NONE TRUE
27015 = Disable Disable TRUE TRUE
27063 = NONE Disable NONE TRUE
27201 = NONE Disable NONE TRUE
27203 = NONE Disable NONE TRUE
27205 = NONE Disable NONE TRUE
27209 = Disable Disable TRUE TRUE
27211 = Disable Disable TRUE TRUE
27213 = Disable Disable TRUE TRUE
27217 = NONE Disable NONE TRUE
27219 = NONE Disable NONE TRUE
27221 = NONE Disable NONE TRUE
27225 = NONE Disable NONE TRUE
27227 = NONE Disable NONE TRUE
27229 = NONE Disable NONE TRUE
27233 = Disable Disable TRUE TRUE
27235 = Disable Disable TRUE TRUE
27241 = NONE Disable NONE TRUE
27245 = NONE Disable NONE TRUE
27249 = Disable Disable TRUE TRUE
27251 = Disable Disable TRUE TRUE
27257 = NONE Disable NONE TRUE
27259 = NONE Disable NONE TRUE
27261 = NONE Disable NONE TRUE
27265 = Disable Disable TRUE TRUE
27267 = Disable Disable TRUE TRUE
27269 = Disable Disable TRUE TRUE
27273 = Disable Disable TRUE TRUE
27277 = Disable Disable TRUE TRUE
27285 = Disable Disable TRUE TRUE
27287 = Disable NONE TRUE NONE
27288 = Disable NONE TRUE NONE
27289 = Disable NONE TRUE NONE
27290 = Disable NONE TRUE NONE
27293 = Disable Disable TRUE TRUE
27297 = Disable Disable TRUE TRUE
27299 = Disable Disable TRUE TRUE
27301 = Disable Disable TRUE TRUE
27305 = Disable Disable TRUE TRUE
27307 = Disable Disable TRUE TRUE
27309 = Disable Disable TRUE TRUE
27313 = NONE Disable NONE TRUE
27315 = NONE Disable NONE TRUE
27317 = NONE Disable NONE TRUE
27321 = NONE Disable NONE TRUE
27325 = NONE Disable NONE TRUE
27373 = Disable Disable TRUE TRUE
27375 = Disable Disable TRUE TRUE
27415 = Disable NONE TRUE NONE
29002 = Disable NONE TRUE NONE
29004 = Disable NONE TRUE NONE
[nLint.Simulation]
22005 = Enable Enable TRUE TRUE
22006 = Disable NONE TRUE NONE
22009 = Enable NONE TRUE NONE
22011 = Enable Enable TRUE TRUE
22013 = Disable Disable TRUE TRUE
22014 = Disable Disable TRUE TRUE
22016 = Disable NONE TRUE NONE
22018 = Disable NONE TRUE NONE
22019 = Enable NONE TRUE NONE
22024 = Disable NONE TRUE NONE
22026 = Disable NONE TRUE NONE
22079 = Enable Enable TRUE TRUE
22082 = Disable Disable TRUE TRUE
22083 = Disable Disable TRUE TRUE
22085 = Enable Enable TRUE TRUE
22089 = Enable NONE TRUE NONE
22091 = Enable NONE TRUE NONE
22109 = Disable NONE TRUE NONE
22112 = Enable NONE TRUE NONE
22113 = Enable Enable TRUE TRUE
22115 = Disable NONE TRUE NONE
22139 = Enable NONE TRUE NONE
22151 = Enable NONE TRUE NONE
22169 = Enable Enable TRUE TRUE
22179 = Enable Enable TRUE TRUE
22187 = Enable NONE TRUE NONE
22195 = Enable Disable TRUE TRUE
22217 = Disable NONE TRUE NONE
22235 = Enable Disable TRUE TRUE
22243 = Enable NONE TRUE NONE
22247 = Disable NONE TRUE NONE
22269 = Enable Disable TRUE TRUE
22271 = Disable Disable TRUE TRUE
22279 = Disable Disable TRUE TRUE
22281 = Enable NONE TRUE NONE
22283 = Enable NONE TRUE NONE
23008 = Disable NONE TRUE NONE
23011 = Enable Enable TRUE TRUE
23013 = Enable Disable TRUE TRUE
23028 = Disable NONE TRUE NONE
23029 = Disable Disable TRUE TRUE
23030 = Enable Disable TRUE TRUE
23123 = Enable Enable TRUE TRUE
23125 = Disable NONE TRUE NONE
23131 = Disable NONE TRUE NONE
27003 = Disable Disable TRUE TRUE
27071 = NONE Disable NONE TRUE
27099 = NONE Disable NONE TRUE
27101 = NONE Disable NONE TRUE
27105 = NONE Disable NONE TRUE
27109 = NONE Disable NONE TRUE
27111 = NONE Disable NONE TRUE
27115 = NONE Disable NONE TRUE
27123 = Enable Disable TRUE TRUE
27125 = Disable Disable TRUE TRUE
27127 = Disable Disable TRUE TRUE
27335 = Disable Disable TRUE TRUE
27337 = Disable NONE TRUE NONE
27550 = NONE Disable NONE TRUE
27573 = NONE Disable NONE TRUE
27661 = Disable Disable TRUE TRUE
27662 = Disable NONE TRUE NONE
27672 = Disable NONE TRUE NONE
27673 = Disable NONE TRUE NONE
27676 = Disable NONE TRUE NONE
27805 = Enable NONE TRUE NONE
27821 = Enable NONE TRUE NONE
29807 = Disable NONE TRUE NONE
[nLint.Synthesis]
22019 = Enable NONE TRUE NONE
22075 = Disable NONE TRUE NONE
22077 = Disable NONE TRUE NONE
22083 = Disable Disable TRUE TRUE
22119 = Enable NONE TRUE NONE
22121 = Enable NONE TRUE NONE
22177 = Enable NONE TRUE NONE
22193 = Disable NONE TRUE NONE
22194 = Disable NONE TRUE NONE
22207 = Disable NONE TRUE NONE
22211 = Enable Enable TRUE TRUE
22213 = Enable Enable TRUE TRUE
22218 = Disable NONE TRUE NONE
22239 = Enable Enable TRUE TRUE
22247 = Disable NONE TRUE NONE
23001 = Disable Disable TRUE TRUE
23002 = Disable Disable TRUE TRUE
23003 = Enable Enable TRUE TRUE
23004 = Disable Disable TRUE TRUE
23005 = Disable Disable TRUE TRUE
23008 = Disable NONE TRUE NONE
23011 = Enable Enable TRUE TRUE
23015 = Enable NONE TRUE NONE
23016 = Enable NONE TRUE NONE
23017 = Enable Disable TRUE TRUE
23021 = Disable NONE TRUE NONE
23025 = Disable Disable TRUE TRUE
23026 = Enable NONE TRUE NONE
23027 = Enable Disable TRUE TRUE
23031 = Enable Enable TRUE TRUE
23033 = Disable NONE TRUE NONE
23034 = Disable NONE TRUE NONE
23035 = Enable NONE TRUE NONE
23037 = Enable NONE TRUE NONE
23039 = Enable Disable TRUE TRUE
23042 = Enable Disable TRUE TRUE
23043 = Enable Disable TRUE TRUE
23044 = Enable Disable TRUE TRUE
23045 = Enable NONE TRUE NONE
23047 = Enable Disable TRUE TRUE
23049 = Enable NONE TRUE NONE
23050 = Enable NONE TRUE NONE
23051 = Enable NONE TRUE NONE
23053 = Enable NONE TRUE NONE
23055 = Enable NONE TRUE NONE
23057 = Enable NONE TRUE NONE
23059 = Enable NONE TRUE NONE
23061 = Enable NONE TRUE NONE
23065 = Enable NONE TRUE NONE
23069 = Enable NONE TRUE NONE
23071 = Enable Disable TRUE TRUE
23073 = Enable NONE TRUE NONE
23075 = Enable NONE TRUE NONE
23077 = Enable NONE TRUE NONE
23079 = Disable NONE TRUE NONE
23083 = Enable NONE TRUE NONE
23087 = Enable NONE TRUE NONE
23089 = Enable NONE TRUE NONE
23091 = Enable NONE TRUE NONE
23095 = Enable NONE TRUE NONE
23097 = Enable NONE TRUE NONE
23099 = Enable NONE TRUE NONE
23101 = Enable NONE TRUE NONE
23103 = Enable NONE TRUE NONE
23105 = Enable NONE TRUE NONE
23107 = Enable NONE TRUE NONE
23109 = Enable NONE TRUE NONE
23115 = Enable NONE TRUE NONE
23117 = Enable NONE TRUE NONE
23119 = Enable NONE TRUE NONE
23123 = Enable Enable TRUE TRUE
23125 = Enable NONE TRUE NONE
23127 = Enable NONE TRUE NONE
23129 = Enable NONE TRUE NONE
23133 = Enable NONE TRUE NONE
23135 = Enable NONE TRUE NONE
23137 = Enable NONE TRUE NONE
24017 = Disable NONE TRUE NONE
27081 = NONE Disable NONE TRUE
27083 = NONE Disable NONE TRUE
27107 = NONE Disable NONE TRUE
27122 = Disable NONE TRUE NONE
27123 = Enable Disable TRUE TRUE
27126 = Enable Disable TRUE TRUE
27128 = Disable Disable TRUE TRUE
27181 = NONE Disable NONE TRUE
27335 = Disable Disable TRUE TRUE
27337 = Disable NONE TRUE NONE
27505 = NONE Disable NONE TRUE
27507 = NONE Disable NONE TRUE
27509 = NONE Disable NONE TRUE
27515 = NONE Disable NONE TRUE
27517 = NONE Disable NONE TRUE
27518 = NONE Disable NONE TRUE
27519 = NONE Disable NONE TRUE
27521 = NONE Disable NONE TRUE
27522 = NONE Disable NONE TRUE
27523 = NONE Disable NONE TRUE
27524 = Enable Disable TRUE TRUE
27525 = NONE Disable NONE TRUE
27529 = NONE Disable NONE TRUE
27531 = NONE Disable NONE TRUE
27533 = NONE Disable NONE TRUE
27535 = NONE Disable NONE TRUE
27536 = NONE Disable NONE TRUE
27537 = NONE Disable NONE TRUE
27539 = NONE Disable NONE TRUE
27541 = NONE Disable NONE TRUE
27543 = NONE Disable NONE TRUE
27545 = NONE Disable NONE TRUE
27549 = NONE Disable NONE TRUE
27550 = NONE Disable NONE TRUE
27551 = NONE Disable NONE TRUE
27553 = NONE Disable NONE TRUE
27557 = NONE Disable NONE TRUE
27559 = NONE Disable NONE TRUE
27561 = NONE Disable NONE TRUE
27563 = NONE Disable NONE TRUE
27565 = NONE Disable NONE TRUE
27567 = NONE Disable NONE TRUE
27571 = NONE Disable NONE TRUE
27573 = NONE Disable NONE TRUE
27575 = NONE Disable NONE TRUE
27577 = NONE Disable NONE TRUE
27581 = NONE Disable NONE TRUE
27585 = NONE Disable NONE TRUE
27587 = NONE Disable NONE TRUE
27589 = NONE Disable NONE TRUE
27595 = NONE Disable NONE TRUE
27597 = NONE Disable NONE TRUE
27598 = NONE Disable NONE TRUE
27599 = NONE Disable NONE TRUE
27601 = NONE Disable NONE TRUE
27605 = NONE Disable NONE TRUE
27609 = NONE Disable NONE TRUE
27610 = NONE Disable NONE TRUE
27613 = NONE Disable NONE TRUE
27615 = NONE Disable NONE TRUE
27617 = NONE Disable NONE TRUE
27619 = NONE Disable NONE TRUE
27621 = NONE Disable NONE TRUE
27623 = NONE Disable NONE TRUE
27625 = NONE Disable NONE TRUE
27627 = NONE Disable NONE TRUE
27629 = NONE Disable NONE TRUE
27631 = NONE Disable NONE TRUE
27633 = NONE Disable NONE TRUE
27635 = NONE Disable NONE TRUE
27639 = NONE Disable NONE TRUE
27641 = NONE Disable NONE TRUE
27643 = NONE Disable NONE TRUE
27645 = NONE Disable NONE TRUE
27649 = NONE Disable NONE TRUE
27651 = NONE Disable NONE TRUE
27653 = NONE Disable NONE TRUE
27655 = NONE Disable NONE TRUE
27657 = NONE Disable NONE TRUE
27661 = Enable Disable TRUE TRUE
27662 = Enable NONE TRUE NONE
27663 = NONE Disable NONE TRUE
27664 = Disable NONE TRUE NONE
27667 = Disable NONE TRUE NONE
27668 = Disable NONE TRUE NONE
27669 = Disable NONE TRUE NONE
27670 = Enable NONE TRUE NONE
27671 = Disable NONE TRUE NONE
27674 = Disable NONE TRUE NONE
27676 = Disable NONE TRUE NONE
27801 = Enable NONE TRUE NONE
27803 = Enable NONE TRUE NONE
27805 = Enable NONE TRUE NONE
27813 = Enable NONE TRUE NONE
27821 = Enable NONE TRUE NONE
27823 = Enable NONE TRUE NONE
27825 = Disable NONE TRUE NONE
27829 = Enable NONE TRUE NONE
29112 = Disable NONE TRUE NONE
29113 = Enable NONE TRUE NONE
29115 = Enable NONE TRUE NONE
29116 = Disable NONE TRUE NONE
29118 = Disable NONE TRUE NONE
29201 = Enable NONE TRUE NONE
29810 = Disable NONE TRUE NONE
29818 = Disable NONE TRUE NONE
29819 = Disable NONE TRUE NONE
29820 = Disable NONE TRUE NONE
29821 = Enable NONE TRUE NONE
29822 = Enable NONE TRUE NONE
29823 = Enable NONE TRUE NONE
[nLint.VITAL Compliant]
27155 = NONE Enable NONE TRUE
27159 = NONE Disable NONE TRUE
27163 = NONE Disable NONE TRUE
[nLint.include]
1 = "Simulation" Enable TRUE
2 = "Synthesis" Enable TRUE
3 = "DFT" Enable TRUE
4 = "ERC" Enable TRUE
5 = "Design Style" Enable TRUE
6 = "Language Construct" Enable TRUE
7 = "HDL Translation" Enable TRUE
8 = "Coding Style" Enable TRUE
9 = "Naming Convention" Enable TRUE
10 = "VITAL Compliant" Disable TRUE
11 = "Clock" Enable TRUE
12 = "Block Interconnect" Enable TRUE
13 = "CTS" Disable TRUE
